Centaur v1.0.0

Credits: Arithmetico

Contact: Arithmetico on AnonOps IRC

Changelog:
	v1.0.0:
	- Initial release

Commands:
	Help: Displays help screen.

	About: Displays about screen.

	Exit: Exits the bot.

	Fetchuserid: Fetches the User id of specified Usernames. 
	You can fetch multiple ids by separating the names with a comma.

	Fetchusers: Fetches all the Users that used specified Hashtags. 
	You can fetch from multiple Hashtags by separating them with a comma. 
	The output can be dumped in a specified file.

	Fetchhashtags: Fetches all the Hashtags used by specified Users. 
	You can fetch from multiple Users by separating them with a comma. 
	The output can be dumped in a specified file.

	Dumpuser: Dumps all the known info about specified Users. 
	You can fetch from multiple Users by separating them with a comma. 
	The output can be dumped in a specified file.

	Fetchdaesh: Fetches a specified amount of possible Daesh accounts using a specified seed User. 
	The output can be dumped in a specified file.
	WHEN FETCHING DAESH ACCOUNTS, MAKE SURE TO VERIFY THE LEGITIMACY FIRST BEFORE REPORTING THEM! THE BOT CAN'T MAKE A DIFFERENCE BETWEEN LEGITIMATE AND DAESH ACCOUNTS! (yet)
